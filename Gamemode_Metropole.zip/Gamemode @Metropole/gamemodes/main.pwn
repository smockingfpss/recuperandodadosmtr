/*
-   Descryptic: Gamemode RolePlay - RP
-   Started: Segunda-Feira 03/03/2025 02:55
-   Status: Desenvolvimento
-   Powered by: Aguiar ID DISCORD: (1285666105427234949)
*/

#include <a_samp>
#include <DOF2>
#include <Pawn.CMD>
#include <file>
#include <sscanf2>
#include <streamer>
#include <foreach>
#include <float>
#include <easyDialog>
#include <textdraw-streamer>
#include <PureChat>

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#include "../resources/core/defines.inc"
#include "../resources/core/variables.inc"
#include "../resources/core/predefined.inc"

#include "../resources/systems/loadscreen.inc"
#include "../resources/systems/notify.inc"
#include "../resources/systems/interaction.inc"
#include "../resources/systems/velocimetro.inc"
#include "../resources/systems/testing.inc"
#include "../resources/systems/fome.inc"
#include "../resources/systems/savedata.inc"
#include "../resources/systems/CharacterCreator.inc"
#include "../resources/systems/DeathPlayer.inc"

#include "../resources/dynamics/bikes.inc"
#include "../resources/dynamics/snack-bars.inc"

#include "../resources/mappers/letreiro.inc"
#include "../resources/mappers/ponto-onibus.inc"

#include "../resources/jobs/job-fisherman.inc"
#include "../resources/jobs/job-bus.inc"

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

main() {
    print("[Metropole:Servidor] Servidor foi carregado por completo."); 
	print("[Metropole:Servidor] Copyright - Metropole RP.");
}

public OnGameModeInit()
{
    ShowPlayerMarkers(0);
	ShowNameTags(0);
	DisableInteriorEnterExits();
 	EnableStuntBonusForAll(0);
    SetGameModeText("Roleplay");

    __CreateLogoMetropole();
    __CreateLoginGlobalMetropole();
    //ManualVehicleEngineAndLights();
    return true;
}

public OnGameModeExit()
{
    DOF2_Exit();
    return true;
}

public OnPlayerConnect(playerid)
{
    __CarregarTextdrawPlayer(playerid);
    __CreateLoginPlayerMetropole(playerid);
    __CreateLoadingScreen(playerid);
    __CreatePersonagemPMetropole(playerid);

    static const e_Clear[pInfo];
    PlayerData[playerid] = e_Clear;
	return true;
}

public OnPlayerDisconnect(playerid, reason)
{
    if(VerificarLogin[playerid] == true) {
        SalvarDados(playerid);
    }
    static const e_Clear[pInfo];
    PlayerData[playerid] = e_Clear;
	return true;
}

public OnPlayerClickMap(playerid, Float:fX, Float:fY, Float:fZ)
{
    SetPlayerPos(playerid, fX, fY, fZ);
    return true;
}

public OnPlayerSpawn(playerid)
{
    if(VerificarLogin[playerid] == false) {
        Kick(playerid);
    }

    for (new i = 0; i < 28; i++)
        TextDrawShowForPlayer(playerid, LogoMetropole_[i]);

	if(isCreatingCharacter[playerid] == true)
	{
		TogglePlayerControllable(playerid, false);
	    SetPlayerVirtualWorld(playerid, playerid);
		SetPlayerInterior(playerid, 0);
        SetPlayerSkin(playerid, 18);
        InterpolateCameraPos(playerid, 371.647186, -2048.128417, 8.148968, 371.647186, -2048.128417, 8.148968, 1000);
        InterpolateCameraLookAt(playerid, 369.848419, -2043.463256, 8.131140, 369.848419, -2043.463134, 8.137457, 1000);
        SetPlayerPos(playerid, 370.4962, -2044.5928, 7.6719);
		SetPlayerFacingAngle(playerid, 201.0849);
	}
	return true;
}


public OnPlayerDeath(playerid, killerid, reason)    
{
	return true;
}

public OnVehicleSpawn(vehicleid)
{
	return true;
}

public OnVehicleDeath(vehicleid, killerid)
{
	return true;
}

public OnPlayerText(playerid, text[])
{
    if(VerificarLogin[playerid] == false)
	{
		MensagemText(playerid, "~r~ERRO: ~w~Voce nao pode falar no chat.");
		return false;
	}
	return true;
}

public OnPlayerCommandText(playerid, cmdtext[])
{
	return false;
}

public OnPlayerEnterVehicle(playerid, vehicleid, ispassenger)
{
    if(GetPlayerState(playerid) == PLAYER_STATE_DRIVER)
    {
        new IdVeiculo = GetPlayerVehicleID(playerid);
	    if(GetVehicleModel(IdVeiculo) != 481)
		{
		    new motor, luzes, alarmev, portas, capo, mala, objective;
		    GetVehicleParamsEx(vehicleid, motor, luzes, alarmev, portas, capo, mala, objective);
		    SetVehicleParamsEx(vehicleid, false, luzes,alarmev, portas, capo, mala, objective);
		    MotorOn[playerid] = 0;
		}
    }
	return 1;
}

public OnPlayerExitVehicle(playerid, vehicleid)
{
    if(GetPlayerState(playerid) == PLAYER_STATE_DRIVER)
    {
        new motor, luzes, alarmev, portas, capo, mala, objective;
        GetVehicleParamsEx(vehicleid, motor, luzes, alarmev, portas, capo, mala, objective);
        SetVehicleParamsEx(vehicleid, false, luzes,alarmev, portas, capo, mala, objective);
        MotorOn[playerid] = 0;
    }
	return 1;
}

public OnPlayerStateChange(playerid, newstate, oldstate)
{
	return true;
}

public OnPlayerEnterCheckpoint(playerid)
{
    DisablePlayerCheckpoint(playerid);
	return true;
}

public OnPlayerLeaveCheckpoint(playerid)
{
	return true;
}

public OnPlayerEnterRaceCheckpoint(playerid)
{
	return true;
}

public OnPlayerLeaveRaceCheckpoint(playerid)
{
	return true;
}

public OnRconCommand(cmd[])
{
	return true;
}

public OnPlayerRequestSpawn(playerid)
{
	return true;
}

public OnObjectMoved(objectid)
{
	return true;
}

public OnPlayerObjectMoved(playerid, objectid)
{
	return true;
}

public OnPlayerPickUpPickup(playerid, pickupid)
{
	return true;
}

public OnVehicleMod(playerid, vehicleid, componentid)
{
	return true;
}

public OnVehiclePaintjob(playerid, vehicleid, paintjobid)
{
	return true;
}

public OnVehicleRespray(playerid, vehicleid, color1, color2)
{
	return true;
}

forward QuebrarText(playerid);
forward UmSegundo();

public OnPlayerSelectedMenuRow(playerid, row)
{
	return true;
}

public OnPlayerExitedMenu(playerid)
{
	return true;
}

public OnPlayerInteriorChange(playerid, newinteriorid, oldinteriorid)
{
	return true;
}

public OnRconLoginAttempt(ip[], password[], success)
{
	return true;
}

public OnPlayerStreamIn(playerid, forplayerid)
{
	return true;
}

public OnPlayerStreamOut(playerid, forplayerid)
{
	return true;
}

public OnVehicleStreamIn(vehicleid, forplayerid)
{
	return true;
}

public OnVehicleStreamOut(vehicleid, forplayerid)
{
	return true;
}

public OnDialogResponse(playerid, dialogid, response, listitem, inputtext[])
{
    if(dialogid == D_SENHA)
    {
        if(response)
        {
            if(strlen(inputtext) < 5 || strlen(inputtext) > 20)
            {
                MensagemText(playerid, "~r~ERRO: ~w~Voce informou uma senha muito pequena ou muito grande, informe senha maior que 5 e menor que 20");
            } else {
                format(VSenha[playerid], 20, inputtext);
				for(new i; i < strlen(inputtext); i++)
				{
					inputtext[i] = '.';
				}
                PlayerTextDrawSetString(playerid, LoginPlayerMetropole__[playerid][1], inputtext);
				PlayerTextDrawShow(playerid, LoginPlayerMetropole__[playerid][1]);
                SHA256_PassHash(inputtext, "aB3!kL9$pQ7#xZ@8*mH^2&dR6+fT%4", VSenha[playerid]);
            	SelectTextDraw(playerid, 0xFF0000AA);
            }
        } else {
            SelectTextDraw(playerid, 0xFF0000AA);
        }
    }
	return true;
}

public OnClickDynamicPlayerTextDraw(playerid, PlayerText:textid)
{
    CallRemoteFunction("OnPlayerClickPanelBike", "dd", playerid, _:textid);
    CallRemoteFunction("OnPlayerClickCreator", "dd", playerid, _:textid);

    if(textid != INVALID_PLAYER_TEXT_DRAW)
	{
        if(textid == LoginPlayerMetropole__[playerid][1])
		{
            if(EstaRegistrado[playerid] == false) {
				CancelSelectTextDraw(playerid);
				ShowPlayerDialog(playerid, D_SENHA, DIALOG_STYLE_PASSWORD, "Senha", "Informe abaixo uma senha para registrar-se.", "Pronto", "Voltar");
			}
            if(EstaRegistrado[playerid] == true) {
				CancelSelectTextDraw(playerid);
				ShowPlayerDialog(playerid, D_SENHA, DIALOG_STYLE_PASSWORD, "Senha", "Informe abaixo sua senha para logar no servidor.", "Pronto", "Voltar");
			}
        }

        if(textid == LoginPlayerMetropole__[playerid][2])
		{
            if(EstaRegistrado[playerid] == false)
            {
                if(new_strcmp(VSenha[playerid], "-1"))
				{
					MensagemText(playerid, "~r~ERRO: ~w~Voce nao digitou a senha na textdraw de senha.");
				} else {
                    InterpolateCameraPos(playerid, 2388.200439, 2110.306640, 32.305969, 2393.203857, 2106.838867, 32.373703, 4000);
                    InterpolateCameraLookAt(playerid, 2384.102050, 2113.170410, 32.253112, 2389.077148, 2109.658447, 32.226806, 4000);

                    TogglePlayerSpectating(playerid, false);
                    TogglePlayerControllable(playerid, false);

                    isCreatingCharacter[playerid] = true;
                    VerificarLogin[playerid] = true;
                    characterAge[playerid] = 18;

                    PlayerData[playerid][Sexo] = 1;
                    SetPlayerVirtualWorld(playerid, playerid);

                    SetPlayerInterior(playerid, 0);
                    SetSpawnInfo(playerid, NO_TEAM, 0, 2388.3210,2110.2537,31.5496,231.3396, 0, 0, 0, 0, 0, 0);
                    SpawnPlayer(playerid);

                    for(new i = 0; i < sizeof(LoginGlobalMetropole__); i++) TextDrawHideForPlayer(playerid, LoginGlobalMetropole__[i]);
                    for(new i = 0; i < sizeof(LoginPlayerMetropole__[]); i++) PlayerTextDrawHide(playerid, LoginPlayerMetropole__[playerid][i]);

                    for(new i = 0; i < sizeof(CreationPersonagemMetropole__[]); i++) PlayerTextDrawShow(playerid, CreationPersonagemMetropole__[playerid][i]);
                    SelectTextDraw(playerid, 0);
                }
            } else if(EstaRegistrado[playerid] == true) {
                if(new_strcmp(VSenha[playerid], "-1")) {
					return MensagemText(playerid, "~r~ERRO: ~w~Voce nao digitou a senha na textdraw de senha.");
				}
                format(arquivo, sizeof(arquivo), PASTA_CONTAS, PlayerName(playerid));
				if(!new_strcmp(VSenha[playerid], DOF2_GetString(arquivo, "Senha")))
				{
                    if(TentativasSenha[playerid] < 3) {
						new string[120];
						TentativasSenha[playerid] ++;
						format(string, sizeof(string), "~r~ERRO: ~w~Voce informou sua senha incorretamente, informe sua senha corretamente (%02d/03).", TentativasSenha[playerid]);
						MensagemText(playerid, string);
					} else {
                        Kick(playerid);
                    }
                } else {
                    for(new i = 0; i < sizeof(LoginGlobalMetropole__); i++) TextDrawHideForPlayer(playerid, LoginGlobalMetropole__[i]);
                    for(new i = 0; i < sizeof(LoginPlayerMetropole__[]); i++) PlayerTextDrawHide(playerid, LoginPlayerMetropole__[playerid][i]);
					CancelSelectTextDraw(playerid);
					CarregarDadosPlayer(playerid);
                }
            }
        }
    }
    return true;
}

public OnPlayerClickPlayer(playerid, clickedplayerid, source)
{
	return true;
}

public QuebrarText(playerid)
{
	return PlayerTextDrawHide(playerid, TextdrawRegistro[9][playerid]);
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

CMD:cv(playerid,params[])
{
    new Vehi[MAX_PLAYERS],CAR,C1,C2,Float:X,Float:Y,Float:Z,Float:R;

    if(sscanf(params,"ddd",CAR,C1,C2)) return  SendClientMessage(playerid, -1, "{FF0000}Use: /cv [CAR] [COR1] [COR2]");
    GetPlayerPos(playerid,X,Y,Z);
    GetPlayerFacingAngle(playerid, R);
    Vehi[playerid] = CreateVehicle(CAR,X,Y,Z,R,C1,C2,-1);
    PutPlayerInVehicle(playerid, Vehi[playerid],0);
    return true;
}

stock __CarregarTextdrawPlayer(playerid)
{
    TextdrawRegistro[0][playerid] = CreatePlayerTextDraw(playerid,402.000000, 119.000000, "_");
    PlayerTextDrawBackgroundColor(playerid,TextdrawRegistro[0][playerid], 255);
    PlayerTextDrawFont(playerid,TextdrawRegistro[0][playerid], 1);
    PlayerTextDrawLetterSize(playerid,TextdrawRegistro[0][playerid], 2.679999, 21.999996);
    PlayerTextDrawColor(playerid,TextdrawRegistro[0][playerid], -1);
    PlayerTextDrawSetOutline(playerid,TextdrawRegistro[0][playerid], 0);
    PlayerTextDrawSetProportional(playerid,TextdrawRegistro[0][playerid], 1);
    PlayerTextDrawSetShadow(playerid,TextdrawRegistro[0][playerid], 1);
    PlayerTextDrawUseBox(playerid,TextdrawRegistro[0][playerid], 1);
    PlayerTextDrawBoxColor(playerid,TextdrawRegistro[0][playerid], 471604479);
    PlayerTextDrawTextSize(playerid,TextdrawRegistro[0][playerid], 236.000000, 189.000000);
    PlayerTextDrawSetSelectable(playerid,TextdrawRegistro[0][playerid], 0);

    TextdrawRegistro[1][playerid] = CreatePlayerTextDraw(playerid,382.000000, 172.000000, "_");
    PlayerTextDrawBackgroundColor(playerid,TextdrawRegistro[1][playerid], 255);
    PlayerTextDrawFont(playerid,TextdrawRegistro[1][playerid], 1);
    PlayerTextDrawLetterSize(playerid,TextdrawRegistro[1][playerid], 0.480000, 1.800000);
    PlayerTextDrawColor(playerid,TextdrawRegistro[1][playerid], -1);
    PlayerTextDrawSetOutline(playerid,TextdrawRegistro[1][playerid], 0);
    PlayerTextDrawSetProportional(playerid,TextdrawRegistro[1][playerid], 1);
    PlayerTextDrawSetShadow(playerid,TextdrawRegistro[1][playerid], 1);
    PlayerTextDrawUseBox(playerid,TextdrawRegistro[1][playerid], 1);
    PlayerTextDrawBoxColor(playerid,TextdrawRegistro[1][playerid], -1061109590);
    PlayerTextDrawTextSize(playerid,TextdrawRegistro[1][playerid], 255.000000, -247.000000);
    PlayerTextDrawSetSelectable(playerid,TextdrawRegistro[1][playerid], 0);

    TextdrawRegistro[2][playerid] = CreatePlayerTextDraw(playerid,307.000000, 146.000000, "hud:ball");
    PlayerTextDrawBackgroundColor(playerid,TextdrawRegistro[2][playerid], 255);
    PlayerTextDrawFont(playerid,TextdrawRegistro[2][playerid], 4);
    PlayerTextDrawLetterSize(playerid,TextdrawRegistro[2][playerid], 0.500000, 1.000000);
    PlayerTextDrawColor(playerid,TextdrawRegistro[2][playerid], -1061109590);
    PlayerTextDrawSetOutline(playerid,TextdrawRegistro[2][playerid], 0);
    PlayerTextDrawSetProportional(playerid,TextdrawRegistro[2][playerid], 1);
    PlayerTextDrawSetShadow(playerid,TextdrawRegistro[2][playerid], 1);
    PlayerTextDrawUseBox(playerid,TextdrawRegistro[2][playerid], 1);
    PlayerTextDrawBoxColor(playerid,TextdrawRegistro[2][playerid], -1061109590);
    PlayerTextDrawTextSize(playerid,TextdrawRegistro[2][playerid], 18.000000, -19.000000);
    PlayerTextDrawSetSelectable(playerid,TextdrawRegistro[2][playerid], 0);

    TextdrawRegistro[3][playerid] = CreatePlayerTextDraw(playerid,305.000000, 159.000000, "hud:ball");
    PlayerTextDrawBackgroundColor(playerid,TextdrawRegistro[3][playerid], 255);
    PlayerTextDrawFont(playerid,TextdrawRegistro[3][playerid], 4);
    PlayerTextDrawLetterSize(playerid,TextdrawRegistro[3][playerid], 0.500000, 1.000000);
    PlayerTextDrawColor(playerid,TextdrawRegistro[3][playerid], -1061109590);
    PlayerTextDrawSetOutline(playerid,TextdrawRegistro[3][playerid], 0);
    PlayerTextDrawSetProportional(playerid,TextdrawRegistro[3][playerid], 1);
    PlayerTextDrawSetShadow(playerid,TextdrawRegistro[3][playerid], 1);
    PlayerTextDrawUseBox(playerid,TextdrawRegistro[3][playerid], 1);
    PlayerTextDrawBoxColor(playerid,TextdrawRegistro[3][playerid], -1061109590);
    PlayerTextDrawTextSize(playerid,TextdrawRegistro[3][playerid], 22.000000, -11.000000);
    PlayerTextDrawSetSelectable(playerid,TextdrawRegistro[3][playerid], 0);

    TextdrawRegistro[4][playerid] = CreatePlayerTextDraw(playerid,382.000000, 205.000000, "_");
    PlayerTextDrawBackgroundColor(playerid,TextdrawRegistro[4][playerid], 255);
    PlayerTextDrawFont(playerid,TextdrawRegistro[4][playerid], 1);
    PlayerTextDrawLetterSize(playerid,TextdrawRegistro[4][playerid], 0.480000, 1.800000);
    PlayerTextDrawColor(playerid,TextdrawRegistro[4][playerid], -1);
    PlayerTextDrawSetOutline(playerid,TextdrawRegistro[4][playerid], 0);
    PlayerTextDrawSetProportional(playerid,TextdrawRegistro[4][playerid], 1);
    PlayerTextDrawSetShadow(playerid,TextdrawRegistro[4][playerid], 1);
    PlayerTextDrawUseBox(playerid,TextdrawRegistro[4][playerid], 1);
    PlayerTextDrawBoxColor(playerid,TextdrawRegistro[4][playerid], -1061109590);
    PlayerTextDrawTextSize(playerid,TextdrawRegistro[4][playerid], 255.000000, -247.000000);
    PlayerTextDrawSetSelectable(playerid,TextdrawRegistro[4][playerid], 0);

    TextdrawRegistro[5][playerid] = CreatePlayerTextDraw(playerid,353.000000, 251.000000, "_");
    PlayerTextDrawBackgroundColor(playerid,TextdrawRegistro[5][playerid], 255);
    PlayerTextDrawFont(playerid,TextdrawRegistro[5][playerid], 1);
    PlayerTextDrawLetterSize(playerid,TextdrawRegistro[5][playerid], 0.529999, 2.299999);
    PlayerTextDrawColor(playerid,TextdrawRegistro[5][playerid], -1);
    PlayerTextDrawSetOutline(playerid,TextdrawRegistro[5][playerid], 0);
    PlayerTextDrawSetProportional(playerid,TextdrawRegistro[5][playerid], 1);
    PlayerTextDrawSetShadow(playerid,TextdrawRegistro[5][playerid], 1);
    PlayerTextDrawUseBox(playerid,TextdrawRegistro[5][playerid], 1);
    PlayerTextDrawBoxColor(playerid,TextdrawRegistro[5][playerid], -2147483393);
    PlayerTextDrawTextSize(playerid,TextdrawRegistro[5][playerid], 284.000000, -252.000000);
    PlayerTextDrawSetSelectable(playerid,TextdrawRegistro[5][playerid], 0);

    TextdrawRegistro[6][playerid] = CreatePlayerTextDraw(playerid,316.000000, 174.000000, "Nome_Sobrenome");
    PlayerTextDrawAlignment(playerid,TextdrawRegistro[6][playerid], 2);
    PlayerTextDrawBackgroundColor(playerid,TextdrawRegistro[6][playerid], 255);
    PlayerTextDrawFont(playerid,TextdrawRegistro[6][playerid], 2);
    PlayerTextDrawLetterSize(playerid,TextdrawRegistro[6][playerid], 0.190000, 1.200000);
    PlayerTextDrawColor(playerid,TextdrawRegistro[6][playerid], -1);
    PlayerTextDrawSetOutline(playerid,TextdrawRegistro[6][playerid], 0);
    PlayerTextDrawSetProportional(playerid,TextdrawRegistro[6][playerid], 1);
    PlayerTextDrawSetShadow(playerid,TextdrawRegistro[6][playerid], 1);
    PlayerTextDrawSetSelectable(playerid,TextdrawRegistro[6][playerid], 0);

    TextdrawRegistro[7][playerid] = CreatePlayerTextDraw(playerid,317.000000, 207.000000, "Senha");
    PlayerTextDrawAlignment(playerid,TextdrawRegistro[7][playerid], 2);
    PlayerTextDrawBackgroundColor(playerid,TextdrawRegistro[7][playerid], 255);
    PlayerTextDrawFont(playerid,TextdrawRegistro[7][playerid], 2);
    PlayerTextDrawLetterSize(playerid,TextdrawRegistro[7][playerid], 0.190000, 1.200000);
    PlayerTextDrawColor(playerid,TextdrawRegistro[7][playerid], -1);
    PlayerTextDrawSetOutline(playerid,TextdrawRegistro[7][playerid], 0);
    PlayerTextDrawSetProportional(playerid,TextdrawRegistro[7][playerid], 1);
    PlayerTextDrawSetShadow(playerid,TextdrawRegistro[7][playerid], 1);
    PlayerTextDrawSetSelectable(playerid,TextdrawRegistro[7][playerid], 1);
    PlayerTextDrawTextSize(playerid,TextdrawRegistro[7][playerid], 30.0, 30.0);

    TextdrawRegistro[8][playerid] = CreatePlayerTextDraw(playerid,318.000000, 255.000000, "Entrar");
    PlayerTextDrawAlignment(playerid,TextdrawRegistro[8][playerid], 2);
    PlayerTextDrawBackgroundColor(playerid,TextdrawRegistro[8][playerid], 255);
    PlayerTextDrawFont(playerid,TextdrawRegistro[8][playerid], 2);
    PlayerTextDrawLetterSize(playerid,TextdrawRegistro[8][playerid], 0.190000, 1.200000);
    PlayerTextDrawColor(playerid,TextdrawRegistro[8][playerid], -1);
    PlayerTextDrawSetOutline(playerid,TextdrawRegistro[8][playerid], 0);
    PlayerTextDrawSetProportional(playerid,TextdrawRegistro[8][playerid], 1);
    PlayerTextDrawSetShadow(playerid,TextdrawRegistro[8][playerid], 1);
    PlayerTextDrawSetSelectable(playerid,TextdrawRegistro[8][playerid], 1);
    PlayerTextDrawTextSize(playerid,TextdrawRegistro[8][playerid], 30.0, 30.0);

    TextdrawRegistro[9][playerid] = CreatePlayerTextDraw(playerid,317.000000, 326.000000, "_"); // erro
    PlayerTextDrawAlignment(playerid,TextdrawRegistro[9][playerid], 2);
    PlayerTextDrawBackgroundColor(playerid,TextdrawRegistro[9][playerid], 255);
    PlayerTextDrawFont(playerid,TextdrawRegistro[9][playerid], 1);
    PlayerTextDrawLetterSize(playerid,TextdrawRegistro[9][playerid], 0.250000, 1.300000);
    PlayerTextDrawColor(playerid,TextdrawRegistro[9][playerid], -1);
    PlayerTextDrawSetOutline(playerid,TextdrawRegistro[9][playerid], 0);
    PlayerTextDrawSetProportional(playerid,TextdrawRegistro[9][playerid], 1);
    PlayerTextDrawSetShadow(playerid,TextdrawRegistro[9][playerid], 1);
    PlayerTextDrawSetSelectable(playerid,TextdrawRegistro[9][playerid], 0);
    return true;
}

stock MensagemText(playerid, const text[])
{
	PlayerTextDrawSetString(playerid, TextdrawRegistro[9][playerid], text);
	PlayerTextDrawShow(playerid, TextdrawRegistro[9][playerid]);
	PlayerPlaySound(playerid,1085,0.0,0.0,0.0);
	SelectTextDraw(playerid, 0xFFFFFFAA);
	return SetTimerEx("QuebrarText", 8000, false, "i", playerid);
}

stock LimparChat(playerid, linhas)
{
	for(new a = 0; a <= linhas; a++) SendClientMessage(playerid, -1, "");
}

stock PlayerName(playerid)
{
    new Nick[MAX_PLAYER_NAME];
    GetPlayerName(playerid, Nick, sizeof(Nick));
    return Nick;
}

stock __CreateLogoMetropole() {
    LogoMetropole_[0] = TextDrawCreate(297.700, 25.298, "LD_BUM:blkdot");
    TextDrawTextSize(LogoMetropole_[0], 10.399, 11.000);
    TextDrawAlignment(LogoMetropole_[0], 1);
    TextDrawColor(LogoMetropole_[0], -1159848449);
    TextDrawSetShadow(LogoMetropole_[0], 0);
    TextDrawSetOutline(LogoMetropole_[0], 0);
    TextDrawBackgroundColor(LogoMetropole_[0], 255);
    TextDrawFont(LogoMetropole_[0], 4);
    TextDrawSetProportional(LogoMetropole_[0], 1);

    LogoMetropole_[1] = TextDrawCreate(288.199, 25.599, "LD_BUM:blkdot");
    TextDrawTextSize(LogoMetropole_[1], 1.699, 7.199);
    TextDrawAlignment(LogoMetropole_[1], 1);
    TextDrawColor(LogoMetropole_[1], -1159848449);
    TextDrawSetShadow(LogoMetropole_[1], 0);
    TextDrawSetOutline(LogoMetropole_[1], 0);
    TextDrawBackgroundColor(LogoMetropole_[1], 255);
    TextDrawFont(LogoMetropole_[1], 4);
    TextDrawSetProportional(LogoMetropole_[1], 1);

    LogoMetropole_[2] = TextDrawCreate(316.397, 19.198, "LD_BUM:blkdot");
    TextDrawTextSize(LogoMetropole_[2], 9.598, 20.899);
    TextDrawAlignment(LogoMetropole_[2], 1);
    TextDrawColor(LogoMetropole_[2], -1159848449);
    TextDrawSetShadow(LogoMetropole_[2], 0);
    TextDrawSetOutline(LogoMetropole_[2], 0);
    TextDrawBackgroundColor(LogoMetropole_[2], 255);
    TextDrawFont(LogoMetropole_[2], 4);
    TextDrawSetProportional(LogoMetropole_[2], 1);

    LogoMetropole_[3] = TextDrawCreate(334.398, 24.999, "LD_BUM:blkdot");
    TextDrawTextSize(LogoMetropole_[3], 9.498, 8.100);
    TextDrawAlignment(LogoMetropole_[3], 1);
    TextDrawColor(LogoMetropole_[3], -1159848449);
    TextDrawSetShadow(LogoMetropole_[3], 0);
    TextDrawSetOutline(LogoMetropole_[3], 0);
    TextDrawBackgroundColor(LogoMetropole_[3], 255);
    TextDrawFont(LogoMetropole_[3], 4);
    TextDrawSetProportional(LogoMetropole_[3], 1);

    LogoMetropole_[4] = TextDrawCreate(306.397, 19.599, "LD_BUM:blkdot");
    TextDrawTextSize(LogoMetropole_[4], 1.299, 7.800);
    TextDrawAlignment(LogoMetropole_[4], 1);
    TextDrawColor(LogoMetropole_[4], -1159848449);
    TextDrawSetShadow(LogoMetropole_[4], 0);
    TextDrawSetOutline(LogoMetropole_[4], 0);
    TextDrawBackgroundColor(LogoMetropole_[4], 255);
    TextDrawFont(LogoMetropole_[4], 4);
    TextDrawSetProportional(LogoMetropole_[4], 1);

    LogoMetropole_[5] = TextDrawCreate(316.296, 38.199, "LD_BUM:blkdot");
    TextDrawTextSize(LogoMetropole_[5], 2.198, 4.599);
    TextDrawAlignment(LogoMetropole_[5], 1);
    TextDrawColor(LogoMetropole_[5], -1159848449);
    TextDrawSetShadow(LogoMetropole_[5], 0);
    TextDrawSetOutline(LogoMetropole_[5], 0);
    TextDrawBackgroundColor(LogoMetropole_[5], 255);
    TextDrawFont(LogoMetropole_[5], 4);
    TextDrawSetProportional(LogoMetropole_[5], 1);

    LogoMetropole_[6] = TextDrawCreate(334.697, 31.599, "LD_BUM:blkdot");
    TextDrawTextSize(LogoMetropole_[6], 1.799, 3.500);
    TextDrawAlignment(LogoMetropole_[6], 1);
    TextDrawColor(LogoMetropole_[6], -1159848449);
    TextDrawSetShadow(LogoMetropole_[6], 0);
    TextDrawSetOutline(LogoMetropole_[6], 0);
    TextDrawBackgroundColor(LogoMetropole_[6], 255);
    TextDrawFont(LogoMetropole_[6], 4);
    TextDrawSetProportional(LogoMetropole_[6], 1);

    LogoMetropole_[7] = TextDrawCreate(305.399, 15.399, "/");
    TextDrawLetterSize(LogoMetropole_[7], 0.888, 0.430);
    TextDrawAlignment(LogoMetropole_[7], 1);
    TextDrawColor(LogoMetropole_[7], -1159848449);
    TextDrawSetShadow(LogoMetropole_[7], 0);
    TextDrawSetOutline(LogoMetropole_[7], 0);
    TextDrawBackgroundColor(LogoMetropole_[7], 150);
    TextDrawFont(LogoMetropole_[7], 1);
    TextDrawSetProportional(LogoMetropole_[7], 1);

    LogoMetropole_[8] = TextDrawCreate(285.100, 23.099, "/");
    TextDrawLetterSize(LogoMetropole_[8], 0.848, 0.360);
    TextDrawAlignment(LogoMetropole_[8], 1);
    TextDrawColor(LogoMetropole_[8], -1159848449);
    TextDrawSetShadow(LogoMetropole_[8], 0);
    TextDrawSetOutline(LogoMetropole_[8], 0);
    TextDrawBackgroundColor(LogoMetropole_[8], -1159848449);
    TextDrawFont(LogoMetropole_[8], 1);
    TextDrawSetProportional(LogoMetropole_[8], 1);

    LogoMetropole_[9] = TextDrawCreate(323.700, 22.499, "/");
    TextDrawLetterSize(LogoMetropole_[9], 0.848, 0.360);
    TextDrawAlignment(LogoMetropole_[9], 1);
    TextDrawColor(LogoMetropole_[9], -1159848449);
    TextDrawSetShadow(LogoMetropole_[9], 0);
    TextDrawSetOutline(LogoMetropole_[9], 0);
    TextDrawBackgroundColor(LogoMetropole_[9], -1159848449);
    TextDrawFont(LogoMetropole_[9], 1);
    TextDrawSetProportional(LogoMetropole_[9], 1);

    LogoMetropole_[10] = TextDrawCreate(316.296, 16.698, "LD_BUM:blkdot");
    TextDrawTextSize(LogoMetropole_[10], 5.198, 2.500);
    TextDrawAlignment(LogoMetropole_[10], 1);
    TextDrawColor(LogoMetropole_[10], -1159848449);
    TextDrawSetShadow(LogoMetropole_[10], 0);
    TextDrawSetOutline(LogoMetropole_[10], 0);
    TextDrawBackgroundColor(LogoMetropole_[10], 255);
    TextDrawFont(LogoMetropole_[10], 4);
    TextDrawSetProportional(LogoMetropole_[10], 1);

    LogoMetropole_[11] = TextDrawCreate(297.996, 22.798, "LD_BUM:blkdot");
    TextDrawTextSize(LogoMetropole_[11], 3.899, 2.500);
    TextDrawAlignment(LogoMetropole_[11], 1);
    TextDrawColor(LogoMetropole_[11], -1159848449);
    TextDrawSetShadow(LogoMetropole_[11], 0);
    TextDrawSetOutline(LogoMetropole_[11], 0);
    TextDrawBackgroundColor(LogoMetropole_[11], 255);
    TextDrawFont(LogoMetropole_[11], 4);
    TextDrawSetProportional(LogoMetropole_[11], 1);

    LogoMetropole_[12] = TextDrawCreate(341.796, 23.798, "LD_BUM:blkdot");
    TextDrawTextSize(LogoMetropole_[12], -7.100, 2.500);
    TextDrawAlignment(LogoMetropole_[12], 1);
    TextDrawColor(LogoMetropole_[12], -1159848449);
    TextDrawSetShadow(LogoMetropole_[12], 0);
    TextDrawSetOutline(LogoMetropole_[12], 0);
    TextDrawBackgroundColor(LogoMetropole_[12], 255);
    TextDrawFont(LogoMetropole_[12], 4);
    TextDrawSetProportional(LogoMetropole_[12], 1);

    LogoMetropole_[13] = TextDrawCreate(303.197, 36.200, "LD_BUM:blkdot");
    TextDrawTextSize(LogoMetropole_[13], 4.899, 2.500);
    TextDrawAlignment(LogoMetropole_[13], 1);
    TextDrawColor(LogoMetropole_[13], -1159848449);
    TextDrawSetShadow(LogoMetropole_[13], 0);
    TextDrawSetOutline(LogoMetropole_[13], 0);
    TextDrawBackgroundColor(LogoMetropole_[13], 255);
    TextDrawFont(LogoMetropole_[13], 4);
    TextDrawSetProportional(LogoMetropole_[13], 1);

    LogoMetropole_[14] = TextDrawCreate(297.799, 40.599, "/");
    TextDrawLetterSize(LogoMetropole_[14], 0.888, -0.449);
    TextDrawAlignment(LogoMetropole_[14], 1);
    TextDrawColor(LogoMetropole_[14], -1159848449);
    TextDrawSetShadow(LogoMetropole_[14], 0);
    TextDrawSetOutline(LogoMetropole_[14], 0);
    TextDrawBackgroundColor(LogoMetropole_[14], -1159848449);
    TextDrawFont(LogoMetropole_[14], 1);
    TextDrawSetProportional(LogoMetropole_[14], 1);

    LogoMetropole_[15] = TextDrawCreate(295.199, 26.899, "/");
    TextDrawLetterSize(LogoMetropole_[15], 0.888, -0.509);
    TextDrawAlignment(LogoMetropole_[15], 1);
    TextDrawColor(LogoMetropole_[15], -1159848449);
    TextDrawSetShadow(LogoMetropole_[15], 0);
    TextDrawSetOutline(LogoMetropole_[15], 0);
    TextDrawBackgroundColor(LogoMetropole_[15], 255);
    TextDrawFont(LogoMetropole_[15], 1);
    TextDrawSetProportional(LogoMetropole_[15], 1);

    LogoMetropole_[16] = TextDrawCreate(314.098, 37.400, "/");
    TextDrawLetterSize(LogoMetropole_[16], 1.108, 0.579);
    TextDrawAlignment(LogoMetropole_[16], 1);
    TextDrawColor(LogoMetropole_[16], -1159848449);
    TextDrawSetShadow(LogoMetropole_[16], 0);
    TextDrawSetOutline(LogoMetropole_[16], 0);
    TextDrawBackgroundColor(LogoMetropole_[16], 255);
    TextDrawFont(LogoMetropole_[16], 1);
    TextDrawSetProportional(LogoMetropole_[16], 1);

    LogoMetropole_[17] = TextDrawCreate(333.299, 30.600, "/");
    TextDrawLetterSize(LogoMetropole_[17], 0.999, 0.519);
    TextDrawAlignment(LogoMetropole_[17], 1);
    TextDrawColor(LogoMetropole_[17], -1159848449);
    TextDrawSetShadow(LogoMetropole_[17], 0);
    TextDrawSetOutline(LogoMetropole_[17], 0);
    TextDrawBackgroundColor(LogoMetropole_[17], 255);
    TextDrawFont(LogoMetropole_[17], 1);
    TextDrawSetProportional(LogoMetropole_[17], 1);

    LogoMetropole_[18] = TextDrawCreate(314.398, 20.200, "/");
    TextDrawLetterSize(LogoMetropole_[18], 0.949, -0.409);
    TextDrawAlignment(LogoMetropole_[18], 1);
    TextDrawColor(LogoMetropole_[18], -1159848449);
    TextDrawSetShadow(LogoMetropole_[18], 0);
    TextDrawSetOutline(LogoMetropole_[18], 0);
    TextDrawBackgroundColor(LogoMetropole_[18], -1159848449);
    TextDrawFont(LogoMetropole_[18], 1);
    TextDrawSetProportional(LogoMetropole_[18], 1);

    LogoMetropole_[19] = TextDrawCreate(317.600, 18.399, "LD_BUM:blkdot");
    TextDrawTextSize(LogoMetropole_[19], 6.798, 22.399);
    TextDrawAlignment(LogoMetropole_[19], 1);
    TextDrawColor(LogoMetropole_[19], -1159848449);
    TextDrawSetShadow(LogoMetropole_[19], 0);
    TextDrawSetOutline(LogoMetropole_[19], 0);
    TextDrawBackgroundColor(LogoMetropole_[19], 255);
    TextDrawFont(LogoMetropole_[19], 4);
    TextDrawSetProportional(LogoMetropole_[19], 1);

    LogoMetropole_[20] = TextDrawCreate(317.600, 40.699, "LD_BUM:blkdot");
    TextDrawTextSize(LogoMetropole_[20], 4.598, 0.899);
    TextDrawAlignment(LogoMetropole_[20], 1);
    TextDrawColor(LogoMetropole_[20], -1159848449);
    TextDrawSetShadow(LogoMetropole_[20], 0);
    TextDrawSetOutline(LogoMetropole_[20], 0);
    TextDrawBackgroundColor(LogoMetropole_[20], 255);
    TextDrawFont(LogoMetropole_[20], 4);
    TextDrawSetProportional(LogoMetropole_[20], 1);

    LogoMetropole_[21] = TextDrawCreate(336.500, 32.500, "LD_BUM:blkdot");
    TextDrawTextSize(LogoMetropole_[21], 4.598, 2.099);
    TextDrawAlignment(LogoMetropole_[21], 1);
    TextDrawColor(LogoMetropole_[21], -1159848449);
    TextDrawSetShadow(LogoMetropole_[21], 0);
    TextDrawSetOutline(LogoMetropole_[21], 0);
    TextDrawBackgroundColor(LogoMetropole_[21], 255);
    TextDrawFont(LogoMetropole_[21], 4);
    TextDrawSetProportional(LogoMetropole_[21], 1);

    LogoMetropole_[22] = TextDrawCreate(287.899, 21.999, "/");
    TextDrawLetterSize(LogoMetropole_[22], 0.848, 0.360);
    TextDrawAlignment(LogoMetropole_[22], 1);
    TextDrawColor(LogoMetropole_[22], -1159848449);
    TextDrawSetShadow(LogoMetropole_[22], 0);
    TextDrawSetOutline(LogoMetropole_[22], 0);
    TextDrawBackgroundColor(LogoMetropole_[22], 150);
    TextDrawFont(LogoMetropole_[22], 1);
    TextDrawSetProportional(LogoMetropole_[22], 1);

    LogoMetropole_[23] = TextDrawCreate(324.100, 21.698, "/");
    TextDrawLetterSize(LogoMetropole_[23], 0.968, 0.430);
    TextDrawTextSize(LogoMetropole_[23], -1.299, 0.000);
    TextDrawAlignment(LogoMetropole_[23], 1);
    TextDrawColor(LogoMetropole_[23], -1159848449);
    TextDrawSetShadow(LogoMetropole_[23], 0);
    TextDrawSetOutline(LogoMetropole_[23], 0);
    TextDrawBackgroundColor(LogoMetropole_[23], 150);
    TextDrawFont(LogoMetropole_[23], 1);
    TextDrawSetProportional(LogoMetropole_[23], 1);

    LogoMetropole_[24] = TextDrawCreate(332.600, 25.499, "/");
    TextDrawLetterSize(LogoMetropole_[24], 0.939, -0.259);
    TextDrawTextSize(LogoMetropole_[24], -1.299, 0.000);
    TextDrawAlignment(LogoMetropole_[24], 1);
    TextDrawColor(LogoMetropole_[24], -1159848449);
    TextDrawSetShadow(LogoMetropole_[24], 0);
    TextDrawSetOutline(LogoMetropole_[24], 0);
    TextDrawBackgroundColor(LogoMetropole_[24], 150);
    TextDrawFont(LogoMetropole_[24], 1);
    TextDrawSetProportional(LogoMetropole_[24], 1);

    LogoMetropole_[25] = TextDrawCreate(301.395, 25.798, "LD_BUM:blkdot");
    TextDrawTextSize(LogoMetropole_[25], 4.899, 2.500);
    TextDrawAlignment(LogoMetropole_[25], 1);
    TextDrawColor(LogoMetropole_[25], -1159848449);
    TextDrawSetShadow(LogoMetropole_[25], 0);
    TextDrawSetOutline(LogoMetropole_[25], 0);
    TextDrawBackgroundColor(LogoMetropole_[25], 255);
    TextDrawFont(LogoMetropole_[25], 4);
    TextDrawSetProportional(LogoMetropole_[25], 1);

    LogoMetropole_[26] = TextDrawCreate(305.500, 16.499, "/");
    TextDrawLetterSize(LogoMetropole_[26], 0.648, 0.360);
    TextDrawAlignment(LogoMetropole_[26], 1);
    TextDrawColor(LogoMetropole_[26], -1159848449);
    TextDrawSetShadow(LogoMetropole_[26], 0);
    TextDrawSetOutline(LogoMetropole_[26], 0);
    TextDrawBackgroundColor(LogoMetropole_[26], 150);
    TextDrawFont(LogoMetropole_[26], 1);
    TextDrawSetProportional(LogoMetropole_[26], 1);

    LogoMetropole_[27] = TextDrawCreate(284.299, 25.500, "METROPOLE");
    TextDrawLetterSize(LogoMetropole_[27], 0.338, 1.350);
    TextDrawAlignment(LogoMetropole_[27], 1);
    TextDrawColor(LogoMetropole_[27], -1);
    TextDrawSetShadow(LogoMetropole_[27], 0);
    TextDrawSetOutline(LogoMetropole_[27], 0);
    TextDrawBackgroundColor(LogoMetropole_[27], 150);
    TextDrawFont(LogoMetropole_[27], 1);
    TextDrawSetProportional(LogoMetropole_[27], 1);
    return true;
}

stock __CreateLoginGlobalMetropole() {
    LoginGlobalMetropole__[0] = TextDrawCreate(-0.333, 0.429, "box");
    TextDrawLetterSize(LoginGlobalMetropole__[0], 0.000, 49.666);
    TextDrawTextSize(LoginGlobalMetropole__[0], 654.000, 0.000);
    TextDrawAlignment(LoginGlobalMetropole__[0], 1);
    TextDrawColor(LoginGlobalMetropole__[0], -1);
    TextDrawUseBox(LoginGlobalMetropole__[0], 1);
    TextDrawBoxColor(LoginGlobalMetropole__[0], 505290495);
    TextDrawSetShadow(LoginGlobalMetropole__[0], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[0], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[0], 255);
    TextDrawFont(LoginGlobalMetropole__[0], 1);
    TextDrawSetProportional(LoginGlobalMetropole__[0], 1);

    LoginGlobalMetropole__[1] = TextDrawCreate(311.999, 158.473, "REGISTRO");
    TextDrawLetterSize(LoginGlobalMetropole__[1], 0.310, 1.496);
    TextDrawTextSize(LoginGlobalMetropole__[1], 0.000, -581.000);
    TextDrawAlignment(LoginGlobalMetropole__[1], 2);
    TextDrawColor(LoginGlobalMetropole__[1], -1260050689);
    TextDrawSetShadow(LoginGlobalMetropole__[1], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[1], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[1], 255);
    TextDrawFont(LoginGlobalMetropole__[1], 1);
    TextDrawSetProportional(LoginGlobalMetropole__[1], 1);

    LoginGlobalMetropole__[2] = TextDrawCreate(268.999, 173.333, "Bem_vindo(a)_ao_servidor!");
    TextDrawLetterSize(LoginGlobalMetropole__[2], 0.147, 0.741);
    TextDrawAlignment(LoginGlobalMetropole__[2], 1);
    TextDrawColor(LoginGlobalMetropole__[2], -2139062017);
    TextDrawSetShadow(LoginGlobalMetropole__[2], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[2], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[2], 255);
    TextDrawFont(LoginGlobalMetropole__[2], 1);
    TextDrawSetProportional(LoginGlobalMetropole__[2], 1);

    LoginGlobalMetropole__[3] = TextDrawCreate(269.000, 182.948, "NOME:");
    TextDrawLetterSize(LoginGlobalMetropole__[3], 0.178, 0.836);
    TextDrawAlignment(LoginGlobalMetropole__[3], 1);
    TextDrawColor(LoginGlobalMetropole__[3], -1260050689);
    TextDrawSetShadow(LoginGlobalMetropole__[3], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[3], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[3], 255);
    TextDrawFont(LoginGlobalMetropole__[3], 1);
    TextDrawSetProportional(LoginGlobalMetropole__[3], 1);

    LoginGlobalMetropole__[4] = TextDrawCreate(268.000, 197.844, "box");
    TextDrawLetterSize(LoginGlobalMetropole__[4], 0.000, 1.133);
    TextDrawTextSize(LoginGlobalMetropole__[4], 356.000, 0.000);
    TextDrawAlignment(LoginGlobalMetropole__[4], 1);
    TextDrawColor(LoginGlobalMetropole__[4], -1);
    TextDrawUseBox(LoginGlobalMetropole__[4], 1);
    TextDrawBoxColor(LoginGlobalMetropole__[4], 909522687);
    TextDrawSetShadow(LoginGlobalMetropole__[4], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[4], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[4], 255);
    TextDrawFont(LoginGlobalMetropole__[4], 1);
    TextDrawSetProportional(LoginGlobalMetropole__[4], 1);

    LoginGlobalMetropole__[5] = TextDrawCreate(270.833, 193.281, "box");
    TextDrawLetterSize(LoginGlobalMetropole__[5], 0.000, 2.099);
    TextDrawTextSize(LoginGlobalMetropole__[5], 352.499, 0.000);
    TextDrawAlignment(LoginGlobalMetropole__[5], 1);
    TextDrawColor(LoginGlobalMetropole__[5], -1);
    TextDrawUseBox(LoginGlobalMetropole__[5], 1);
    TextDrawBoxColor(LoginGlobalMetropole__[5], 909522687);
    TextDrawSetShadow(LoginGlobalMetropole__[5], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[5], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[5], 255);
    TextDrawFont(LoginGlobalMetropole__[5], 1);
    TextDrawSetProportional(LoginGlobalMetropole__[5], 1);

    LoginGlobalMetropole__[6] = TextDrawCreate(264.900, 189.829, "ld_beat:chit");
    TextDrawTextSize(LoginGlobalMetropole__[6], 9.000, 10.000);
    TextDrawAlignment(LoginGlobalMetropole__[6], 1);
    TextDrawColor(LoginGlobalMetropole__[6], 909522687);
    TextDrawSetShadow(LoginGlobalMetropole__[6], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[6], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[6], 255);
    TextDrawFont(LoginGlobalMetropole__[6], 4);
    TextDrawSetProportional(LoginGlobalMetropole__[6], 0);

    LoginGlobalMetropole__[7] = TextDrawCreate(264.900, 205.430, "ld_beat:chit");
    TextDrawTextSize(LoginGlobalMetropole__[7], 9.000, 10.000);
    TextDrawAlignment(LoginGlobalMetropole__[7], 1);
    TextDrawColor(LoginGlobalMetropole__[7], 909522687);
    TextDrawSetShadow(LoginGlobalMetropole__[7], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[7], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[7], 255);
    TextDrawFont(LoginGlobalMetropole__[7], 4);
    TextDrawSetProportional(LoginGlobalMetropole__[7], 0);

    LoginGlobalMetropole__[8] = TextDrawCreate(349.799, 189.838, "ld_beat:chit");
    TextDrawTextSize(LoginGlobalMetropole__[8], 9.000, 10.000);
    TextDrawAlignment(LoginGlobalMetropole__[8], 1);
    TextDrawColor(LoginGlobalMetropole__[8], 909522687);
    TextDrawSetShadow(LoginGlobalMetropole__[8], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[8], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[8], 255);
    TextDrawFont(LoginGlobalMetropole__[8], 4);
    TextDrawSetProportional(LoginGlobalMetropole__[8], 0);

    LoginGlobalMetropole__[9] = TextDrawCreate(349.599, 205.338, "ld_beat:chit");
    TextDrawTextSize(LoginGlobalMetropole__[9], 9.000, 10.000);
    TextDrawAlignment(LoginGlobalMetropole__[9], 1);
    TextDrawColor(LoginGlobalMetropole__[9], 909522687);
    TextDrawSetShadow(LoginGlobalMetropole__[9], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[9], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[9], 255);
    TextDrawFont(LoginGlobalMetropole__[9], 4);
    TextDrawSetProportional(LoginGlobalMetropole__[9], 0);

    LoginGlobalMetropole__[10] = TextDrawCreate(269.000, 215.650, "SENHA:");
    TextDrawLetterSize(LoginGlobalMetropole__[10], 0.168, 0.836);
    TextDrawAlignment(LoginGlobalMetropole__[10], 1);
    TextDrawColor(LoginGlobalMetropole__[10], -1260050689);
    TextDrawSetShadow(LoginGlobalMetropole__[10], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[10], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[10], 255);
    TextDrawFont(LoginGlobalMetropole__[10], 1);
    TextDrawSetProportional(LoginGlobalMetropole__[10], 1);

    LoginGlobalMetropole__[11] = TextDrawCreate(268.000, 230.217, "box");
    TextDrawLetterSize(LoginGlobalMetropole__[11], 0.000, 1.133);
    TextDrawTextSize(LoginGlobalMetropole__[11], 356.000, 0.000);
    TextDrawAlignment(LoginGlobalMetropole__[11], 1);
    TextDrawColor(LoginGlobalMetropole__[11], -1);
    TextDrawUseBox(LoginGlobalMetropole__[11], 1);
    TextDrawBoxColor(LoginGlobalMetropole__[11], 909522687);
    TextDrawSetShadow(LoginGlobalMetropole__[11], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[11], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[11], 255);
    TextDrawFont(LoginGlobalMetropole__[11], 1);
    TextDrawSetProportional(LoginGlobalMetropole__[11], 1);

    LoginGlobalMetropole__[12] = TextDrawCreate(270.833, 225.883, "box");
    TextDrawLetterSize(LoginGlobalMetropole__[12], 0.000, 2.099);
    TextDrawTextSize(LoginGlobalMetropole__[12], 352.499, 0.000);
    TextDrawAlignment(LoginGlobalMetropole__[12], 1);
    TextDrawColor(LoginGlobalMetropole__[12], -1);
    TextDrawUseBox(LoginGlobalMetropole__[12], 1);
    TextDrawBoxColor(LoginGlobalMetropole__[12], 909522687);
    TextDrawSetShadow(LoginGlobalMetropole__[12], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[12], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[12], 255);
    TextDrawFont(LoginGlobalMetropole__[12], 1);
    TextDrawSetProportional(LoginGlobalMetropole__[12], 1);

    LoginGlobalMetropole__[13] = TextDrawCreate(265.000, 222.590, "ld_beat:chit");
    TextDrawTextSize(LoginGlobalMetropole__[13], 9.000, 10.000);
    TextDrawAlignment(LoginGlobalMetropole__[13], 1);
    TextDrawColor(LoginGlobalMetropole__[13], 909522687);
    TextDrawSetShadow(LoginGlobalMetropole__[13], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[13], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[13], 255);
    TextDrawFont(LoginGlobalMetropole__[13], 4);
    TextDrawSetProportional(LoginGlobalMetropole__[13], 0);

    LoginGlobalMetropole__[14] = TextDrawCreate(264.933, 238.153, "ld_beat:chit");
    TextDrawTextSize(LoginGlobalMetropole__[14], 9.000, 10.000);
    TextDrawAlignment(LoginGlobalMetropole__[14], 1);
    TextDrawColor(LoginGlobalMetropole__[14], 909522687);
    TextDrawSetShadow(LoginGlobalMetropole__[14], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[14], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[14], 255);
    TextDrawFont(LoginGlobalMetropole__[14], 4);
    TextDrawSetProportional(LoginGlobalMetropole__[14], 0);

    LoginGlobalMetropole__[15] = TextDrawCreate(349.699, 222.605, "ld_beat:chit");
    TextDrawTextSize(LoginGlobalMetropole__[15], 9.000, 10.000);
    TextDrawAlignment(LoginGlobalMetropole__[15], 1);
    TextDrawColor(LoginGlobalMetropole__[15], 909522687);
    TextDrawSetShadow(LoginGlobalMetropole__[15], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[15], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[15], 255);
    TextDrawFont(LoginGlobalMetropole__[15], 4);
    TextDrawSetProportional(LoginGlobalMetropole__[15], 0);

    LoginGlobalMetropole__[16] = TextDrawCreate(349.699, 238.206, "ld_beat:chit");
    TextDrawTextSize(LoginGlobalMetropole__[16], 9.000, 10.000);
    TextDrawAlignment(LoginGlobalMetropole__[16], 1);
    TextDrawColor(LoginGlobalMetropole__[16], 909522687);
    TextDrawSetShadow(LoginGlobalMetropole__[16], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[16], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[16], 255);
    TextDrawFont(LoginGlobalMetropole__[16], 4);
    TextDrawSetProportional(LoginGlobalMetropole__[16], 0);

    LoginGlobalMetropole__[17] = TextDrawCreate(268.000, 260.619, "box");
    TextDrawLetterSize(LoginGlobalMetropole__[17], 0.000, 1.133);
    TextDrawTextSize(LoginGlobalMetropole__[17], 356.000, 0.000);
    TextDrawAlignment(LoginGlobalMetropole__[17], 1);
    TextDrawColor(LoginGlobalMetropole__[17], -1);
    TextDrawUseBox(LoginGlobalMetropole__[17], 1);
    TextDrawBoxColor(LoginGlobalMetropole__[17], -1260050689);
    TextDrawSetShadow(LoginGlobalMetropole__[17], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[17], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[17], 255);
    TextDrawFont(LoginGlobalMetropole__[17], 1);
    TextDrawSetProportional(LoginGlobalMetropole__[17], 1);

    LoginGlobalMetropole__[18] = TextDrawCreate(270.833, 256.085, "box");
    TextDrawLetterSize(LoginGlobalMetropole__[18], 0.000, 2.099);
    TextDrawTextSize(LoginGlobalMetropole__[18], 352.499, 0.000);
    TextDrawAlignment(LoginGlobalMetropole__[18], 1);
    TextDrawColor(LoginGlobalMetropole__[18], -1);
    TextDrawUseBox(LoginGlobalMetropole__[18], 1);
    TextDrawBoxColor(LoginGlobalMetropole__[18], -1260050689);
    TextDrawSetShadow(LoginGlobalMetropole__[18], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[18], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[18], 255);
    TextDrawFont(LoginGlobalMetropole__[18], 1);
    TextDrawSetProportional(LoginGlobalMetropole__[18], 1);

    LoginGlobalMetropole__[19] = TextDrawCreate(264.933, 252.731, "ld_beat:chit");
    TextDrawTextSize(LoginGlobalMetropole__[19], 9.000, 10.000);
    TextDrawAlignment(LoginGlobalMetropole__[19], 1);
    TextDrawColor(LoginGlobalMetropole__[19], -1260050689);
    TextDrawSetShadow(LoginGlobalMetropole__[19], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[19], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[19], 255);
    TextDrawFont(LoginGlobalMetropole__[19], 4);
    TextDrawSetProportional(LoginGlobalMetropole__[19], 0);

    LoginGlobalMetropole__[20] = TextDrawCreate(264.933, 268.332, "ld_beat:chit");
    TextDrawTextSize(LoginGlobalMetropole__[20], 9.000, 10.000);
    TextDrawAlignment(LoginGlobalMetropole__[20], 1);
    TextDrawColor(LoginGlobalMetropole__[20], -1260050689);
    TextDrawSetShadow(LoginGlobalMetropole__[20], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[20], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[20], 255);
    TextDrawFont(LoginGlobalMetropole__[20], 4);
    TextDrawSetProportional(LoginGlobalMetropole__[20], 0);

    LoginGlobalMetropole__[21] = TextDrawCreate(349.766, 252.769, "ld_beat:chit");
    TextDrawTextSize(LoginGlobalMetropole__[21], 9.000, 10.000);
    TextDrawAlignment(LoginGlobalMetropole__[21], 1);
    TextDrawColor(LoginGlobalMetropole__[21], -1260050689);
    TextDrawSetShadow(LoginGlobalMetropole__[21], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[21], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[21], 255);
    TextDrawFont(LoginGlobalMetropole__[21], 4);
    TextDrawSetProportional(LoginGlobalMetropole__[21], 0);

    LoginGlobalMetropole__[22] = TextDrawCreate(349.766, 268.270, "ld_beat:chit");
    TextDrawTextSize(LoginGlobalMetropole__[22], 9.000, 10.000);
    TextDrawAlignment(LoginGlobalMetropole__[22], 1);
    TextDrawColor(LoginGlobalMetropole__[22], -1260050689);
    TextDrawSetShadow(LoginGlobalMetropole__[22], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[22], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[22], 255);
    TextDrawFont(LoginGlobalMetropole__[22], 4);
    TextDrawSetProportional(LoginGlobalMetropole__[22], 0);

    LoginGlobalMetropole__[23] = TextDrawCreate(344.899, 195.301, "ld_beat:chit");
    TextDrawTextSize(LoginGlobalMetropole__[23], 8.000, 9.000);
    TextDrawAlignment(LoginGlobalMetropole__[23], 1);
    TextDrawColor(LoginGlobalMetropole__[23], -2139062017);
    TextDrawSetShadow(LoginGlobalMetropole__[23], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[23], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[23], 255);
    TextDrawFont(LoginGlobalMetropole__[23], 4);
    TextDrawSetProportional(LoginGlobalMetropole__[23], 0);

    LoginGlobalMetropole__[24] = TextDrawCreate(342.066, 202.901, "ld_beat:chit");
    TextDrawTextSize(LoginGlobalMetropole__[24], 14.000, 8.000);
    TextDrawAlignment(LoginGlobalMetropole__[24], 1);
    TextDrawColor(LoginGlobalMetropole__[24], -2139062017);
    TextDrawSetShadow(LoginGlobalMetropole__[24], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[24], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[24], 255);
    TextDrawFont(LoginGlobalMetropole__[24], 4);
    TextDrawSetProportional(LoginGlobalMetropole__[24], 0);

    LoginGlobalMetropole__[25] = TextDrawCreate(347.100, 235.470, "box");
    TextDrawLetterSize(LoginGlobalMetropole__[25], 0.000, 0.499);
    TextDrawTextSize(LoginGlobalMetropole__[25], 351.100, 0.000);
    TextDrawAlignment(LoginGlobalMetropole__[25], 1);
    TextDrawColor(LoginGlobalMetropole__[25], -2139062017);
    TextDrawUseBox(LoginGlobalMetropole__[25], 1);
    TextDrawBoxColor(LoginGlobalMetropole__[25], -2139062017);
    TextDrawSetShadow(LoginGlobalMetropole__[25], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[25], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[25], 255);
    TextDrawFont(LoginGlobalMetropole__[25], 1);
    TextDrawSetProportional(LoginGlobalMetropole__[25], 1);

    LoginGlobalMetropole__[26] = TextDrawCreate(346.733, 225.033, "0");
    TextDrawLetterSize(LoginGlobalMetropole__[26], 0.202, 1.653);
    TextDrawTextSize(LoginGlobalMetropole__[26], -10.000, 0.000);
    TextDrawAlignment(LoginGlobalMetropole__[26], 1);
    TextDrawColor(LoginGlobalMetropole__[26], -2139062017);
    TextDrawSetShadow(LoginGlobalMetropole__[26], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[26], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[26], 255);
    TextDrawFont(LoginGlobalMetropole__[26], 2);
    TextDrawSetProportional(LoginGlobalMetropole__[26], 1);

    LoginGlobalMetropole__[27] = TextDrawCreate(347.966, 224.414, ".");
    TextDrawLetterSize(LoginGlobalMetropole__[27], 0.200, 1.911);
    TextDrawAlignment(LoginGlobalMetropole__[27], 1);
    TextDrawColor(LoginGlobalMetropole__[27], 255);
    TextDrawSetShadow(LoginGlobalMetropole__[27], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[27], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[27], 255);
    TextDrawFont(LoginGlobalMetropole__[27], 1);
    TextDrawSetProportional(LoginGlobalMetropole__[27], 1);

    LoginGlobalMetropole__[28] = TextDrawCreate(-18.000, -102.000, "PARTICLE:lamp_shad_64");
    TextDrawTextSize(LoginGlobalMetropole__[28], 1210.000, 960.000);
    TextDrawAlignment(LoginGlobalMetropole__[28], 1);
    TextDrawColor(LoginGlobalMetropole__[28], -196);
    TextDrawSetShadow(LoginGlobalMetropole__[28], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[28], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[28], 255);
    TextDrawFont(LoginGlobalMetropole__[28], 4);
    TextDrawSetProportional(LoginGlobalMetropole__[28], 1);

    LoginGlobalMetropole__[29] = TextDrawCreate(297.700, 25.298, "LD_BUM:blkdot");
    TextDrawTextSize(LoginGlobalMetropole__[29], 10.399, 11.000);
    TextDrawAlignment(LoginGlobalMetropole__[29], 1);
    TextDrawColor(LoginGlobalMetropole__[29], -1159848449);
    TextDrawSetShadow(LoginGlobalMetropole__[29], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[29], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[29], 255);
    TextDrawFont(LoginGlobalMetropole__[29], 4);
    TextDrawSetProportional(LoginGlobalMetropole__[29], 1);

    LoginGlobalMetropole__[30] = TextDrawCreate(288.199, 25.599, "LD_BUM:blkdot");
    TextDrawTextSize(LoginGlobalMetropole__[30], 1.699, 7.198);
    TextDrawAlignment(LoginGlobalMetropole__[30], 1);
    TextDrawColor(LoginGlobalMetropole__[30], -1159848449);
    TextDrawSetShadow(LoginGlobalMetropole__[30], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[30], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[30], 255);
    TextDrawFont(LoginGlobalMetropole__[30], 4);
    TextDrawSetProportional(LoginGlobalMetropole__[30], 1);

    LoginGlobalMetropole__[31] = TextDrawCreate(316.397, 19.197, "LD_BUM:blkdot");
    TextDrawTextSize(LoginGlobalMetropole__[31], 9.597, 20.899);
    TextDrawAlignment(LoginGlobalMetropole__[31], 1);
    TextDrawColor(LoginGlobalMetropole__[31], -1159848449);
    TextDrawSetShadow(LoginGlobalMetropole__[31], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[31], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[31], 255);
    TextDrawFont(LoginGlobalMetropole__[31], 4);
    TextDrawSetProportional(LoginGlobalMetropole__[31], 1);

    LoginGlobalMetropole__[32] = TextDrawCreate(334.398, 24.999, "LD_BUM:blkdot");
    TextDrawTextSize(LoginGlobalMetropole__[32], 9.498, 8.100);
    TextDrawAlignment(LoginGlobalMetropole__[32], 1);
    TextDrawColor(LoginGlobalMetropole__[32], -1159848449);
    TextDrawSetShadow(LoginGlobalMetropole__[32], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[32], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[32], 255);
    TextDrawFont(LoginGlobalMetropole__[32], 4);
    TextDrawSetProportional(LoginGlobalMetropole__[32], 1);

    LoginGlobalMetropole__[33] = TextDrawCreate(306.397, 19.599, "LD_BUM:blkdot");
    TextDrawTextSize(LoginGlobalMetropole__[33], 1.299, 7.800);
    TextDrawAlignment(LoginGlobalMetropole__[33], 1);
    TextDrawColor(LoginGlobalMetropole__[33], -1159848449);
    TextDrawSetShadow(LoginGlobalMetropole__[33], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[33], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[33], 255);
    TextDrawFont(LoginGlobalMetropole__[33], 4);
    TextDrawSetProportional(LoginGlobalMetropole__[33], 1);

    LoginGlobalMetropole__[34] = TextDrawCreate(316.295, 38.199, "LD_BUM:blkdot");
    TextDrawTextSize(LoginGlobalMetropole__[34], 2.197, 4.598);
    TextDrawAlignment(LoginGlobalMetropole__[34], 1);
    TextDrawColor(LoginGlobalMetropole__[34], -1159848449);
    TextDrawSetShadow(LoginGlobalMetropole__[34], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[34], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[34], 255);
    TextDrawFont(LoginGlobalMetropole__[34], 4);
    TextDrawSetProportional(LoginGlobalMetropole__[34], 1);

    LoginGlobalMetropole__[35] = TextDrawCreate(334.696, 31.599, "LD_BUM:blkdot");
    TextDrawTextSize(LoginGlobalMetropole__[35], 1.799, 3.500);
    TextDrawAlignment(LoginGlobalMetropole__[35], 1);
    TextDrawColor(LoginGlobalMetropole__[35], -1159848449);
    TextDrawSetShadow(LoginGlobalMetropole__[35], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[35], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[35], 255);
    TextDrawFont(LoginGlobalMetropole__[35], 4);
    TextDrawSetProportional(LoginGlobalMetropole__[35], 1);

    LoginGlobalMetropole__[36] = TextDrawCreate(305.398, 15.399, "/");
    TextDrawLetterSize(LoginGlobalMetropole__[36], 0.888, 0.430);
    TextDrawAlignment(LoginGlobalMetropole__[36], 1);
    TextDrawColor(LoginGlobalMetropole__[36], -1159848449);
    TextDrawSetShadow(LoginGlobalMetropole__[36], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[36], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[36], 150);
    TextDrawFont(LoginGlobalMetropole__[36], 1);
    TextDrawSetProportional(LoginGlobalMetropole__[36], 1);

    LoginGlobalMetropole__[37] = TextDrawCreate(285.100, 23.099, "/");
    TextDrawLetterSize(LoginGlobalMetropole__[37], 0.847, 0.360);
    TextDrawAlignment(LoginGlobalMetropole__[37], 1);
    TextDrawColor(LoginGlobalMetropole__[37], -1159848449);
    TextDrawSetShadow(LoginGlobalMetropole__[37], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[37], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[37], -1159848449);
    TextDrawFont(LoginGlobalMetropole__[37], 1);
    TextDrawSetProportional(LoginGlobalMetropole__[37], 1);

    LoginGlobalMetropole__[38] = TextDrawCreate(323.700, 22.499, "/");
    TextDrawLetterSize(LoginGlobalMetropole__[38], 0.847, 0.360);
    TextDrawAlignment(LoginGlobalMetropole__[38], 1);
    TextDrawColor(LoginGlobalMetropole__[38], -1159848449);
    TextDrawSetShadow(LoginGlobalMetropole__[38], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[38], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[38], -1159848449);
    TextDrawFont(LoginGlobalMetropole__[38], 1);
    TextDrawSetProportional(LoginGlobalMetropole__[38], 1);

    LoginGlobalMetropole__[39] = TextDrawCreate(316.295, 16.697, "LD_BUM:blkdot");
    TextDrawTextSize(LoginGlobalMetropole__[39], 5.197, 2.500);
    TextDrawAlignment(LoginGlobalMetropole__[39], 1);
    TextDrawColor(LoginGlobalMetropole__[39], -1159848449);
    TextDrawSetShadow(LoginGlobalMetropole__[39], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[39], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[39], 255);
    TextDrawFont(LoginGlobalMetropole__[39], 4);
    TextDrawSetProportional(LoginGlobalMetropole__[39], 1);

    LoginGlobalMetropole__[40] = TextDrawCreate(297.996, 22.798, "LD_BUM:blkdot");
    TextDrawTextSize(LoginGlobalMetropole__[40], 3.898, 2.500);
    TextDrawAlignment(LoginGlobalMetropole__[40], 1);
    TextDrawColor(LoginGlobalMetropole__[40], -1159848449);
    TextDrawSetShadow(LoginGlobalMetropole__[40], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[40], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[40], 255);
    TextDrawFont(LoginGlobalMetropole__[40], 4);
    TextDrawSetProportional(LoginGlobalMetropole__[40], 1);

    LoginGlobalMetropole__[41] = TextDrawCreate(341.795, 23.798, "LD_BUM:blkdot");
    TextDrawTextSize(LoginGlobalMetropole__[41], -7.099, 2.500);
    TextDrawAlignment(LoginGlobalMetropole__[41], 1);
    TextDrawColor(LoginGlobalMetropole__[41], -1159848449);
    TextDrawSetShadow(LoginGlobalMetropole__[41], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[41], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[41], 255);
    TextDrawFont(LoginGlobalMetropole__[41], 4);
    TextDrawSetProportional(LoginGlobalMetropole__[41], 1);

    LoginGlobalMetropole__[42] = TextDrawCreate(303.196, 36.200, "LD_BUM:blkdot");
    TextDrawTextSize(LoginGlobalMetropole__[42], 4.899, 2.500);
    TextDrawAlignment(LoginGlobalMetropole__[42], 1);
    TextDrawColor(LoginGlobalMetropole__[42], -1159848449);
    TextDrawSetShadow(LoginGlobalMetropole__[42], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[42], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[42], 255);
    TextDrawFont(LoginGlobalMetropole__[42], 4);
    TextDrawSetProportional(LoginGlobalMetropole__[42], 1);

    LoginGlobalMetropole__[43] = TextDrawCreate(297.799, 40.598, "/");
    TextDrawLetterSize(LoginGlobalMetropole__[43], 0.888, -0.449);
    TextDrawAlignment(LoginGlobalMetropole__[43], 1);
    TextDrawColor(LoginGlobalMetropole__[43], -1159848449);
    TextDrawSetShadow(LoginGlobalMetropole__[43], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[43], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[43], -1159848449);
    TextDrawFont(LoginGlobalMetropole__[43], 1);
    TextDrawSetProportional(LoginGlobalMetropole__[43], 1);

    LoginGlobalMetropole__[44] = TextDrawCreate(295.199, 26.899, "/");
    TextDrawLetterSize(LoginGlobalMetropole__[44], 0.888, -0.509);
    TextDrawAlignment(LoginGlobalMetropole__[44], 1);
    TextDrawColor(LoginGlobalMetropole__[44], -1159848449);
    TextDrawSetShadow(LoginGlobalMetropole__[44], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[44], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[44], 255);
    TextDrawFont(LoginGlobalMetropole__[44], 1);
    TextDrawSetProportional(LoginGlobalMetropole__[44], 1);

    LoginGlobalMetropole__[45] = TextDrawCreate(314.097, 37.400, "/");
    TextDrawLetterSize(LoginGlobalMetropole__[45], 1.108, 0.578);
    TextDrawAlignment(LoginGlobalMetropole__[45], 1);
    TextDrawColor(LoginGlobalMetropole__[45], -1159848449);
    TextDrawSetShadow(LoginGlobalMetropole__[45], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[45], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[45], 255);
    TextDrawFont(LoginGlobalMetropole__[45], 1);
    TextDrawSetProportional(LoginGlobalMetropole__[45], 1);

    LoginGlobalMetropole__[46] = TextDrawCreate(333.299, 30.600, "/");
    TextDrawLetterSize(LoginGlobalMetropole__[46], 0.999, 0.518);
    TextDrawAlignment(LoginGlobalMetropole__[46], 1);
    TextDrawColor(LoginGlobalMetropole__[46], -1159848449);
    TextDrawSetShadow(LoginGlobalMetropole__[46], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[46], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[46], 255);
    TextDrawFont(LoginGlobalMetropole__[46], 1);
    TextDrawSetProportional(LoginGlobalMetropole__[46], 1);

    LoginGlobalMetropole__[47] = TextDrawCreate(314.398, 20.200, "/");
    TextDrawLetterSize(LoginGlobalMetropole__[47], 0.949, -0.409);
    TextDrawAlignment(LoginGlobalMetropole__[47], 1);
    TextDrawColor(LoginGlobalMetropole__[47], -1159848449);
    TextDrawSetShadow(LoginGlobalMetropole__[47], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[47], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[47], -1159848449);
    TextDrawFont(LoginGlobalMetropole__[47], 1);
    TextDrawSetProportional(LoginGlobalMetropole__[47], 1);

    LoginGlobalMetropole__[48] = TextDrawCreate(317.600, 18.399, "LD_BUM:blkdot");
    TextDrawTextSize(LoginGlobalMetropole__[48], 6.797, 22.399);
    TextDrawAlignment(LoginGlobalMetropole__[48], 1);
    TextDrawColor(LoginGlobalMetropole__[48], -1159848449);
    TextDrawSetShadow(LoginGlobalMetropole__[48], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[48], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[48], 255);
    TextDrawFont(LoginGlobalMetropole__[48], 4);
    TextDrawSetProportional(LoginGlobalMetropole__[48], 1);

    LoginGlobalMetropole__[49] = TextDrawCreate(317.600, 40.699, "LD_BUM:blkdot");
    TextDrawTextSize(LoginGlobalMetropole__[49], 4.598, 0.898);
    TextDrawAlignment(LoginGlobalMetropole__[49], 1);
    TextDrawColor(LoginGlobalMetropole__[49], -1159848449);
    TextDrawSetShadow(LoginGlobalMetropole__[49], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[49], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[49], 255);
    TextDrawFont(LoginGlobalMetropole__[49], 4);
    TextDrawSetProportional(LoginGlobalMetropole__[49], 1);

    LoginGlobalMetropole__[50] = TextDrawCreate(336.500, 32.500, "LD_BUM:blkdot");
    TextDrawTextSize(LoginGlobalMetropole__[50], 4.598, 2.098);
    TextDrawAlignment(LoginGlobalMetropole__[50], 1);
    TextDrawColor(LoginGlobalMetropole__[50], -1159848449);
    TextDrawSetShadow(LoginGlobalMetropole__[50], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[50], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[50], 255);
    TextDrawFont(LoginGlobalMetropole__[50], 4);
    TextDrawSetProportional(LoginGlobalMetropole__[50], 1);

    LoginGlobalMetropole__[51] = TextDrawCreate(287.898, 21.999, "/");
    TextDrawLetterSize(LoginGlobalMetropole__[51], 0.847, 0.360);
    TextDrawAlignment(LoginGlobalMetropole__[51], 1);
    TextDrawColor(LoginGlobalMetropole__[51], -1159848449);
    TextDrawSetShadow(LoginGlobalMetropole__[51], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[51], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[51], 150);
    TextDrawFont(LoginGlobalMetropole__[51], 1);
    TextDrawSetProportional(LoginGlobalMetropole__[51], 1);

    LoginGlobalMetropole__[52] = TextDrawCreate(324.100, 21.697, "/");
    TextDrawLetterSize(LoginGlobalMetropole__[52], 0.967, 0.430);
    TextDrawTextSize(LoginGlobalMetropole__[52], -1.299, 0.000);
    TextDrawAlignment(LoginGlobalMetropole__[52], 1);
    TextDrawColor(LoginGlobalMetropole__[52], -1159848449);
    TextDrawSetShadow(LoginGlobalMetropole__[52], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[52], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[52], 150);
    TextDrawFont(LoginGlobalMetropole__[52], 1);
    TextDrawSetProportional(LoginGlobalMetropole__[52], 1);

    LoginGlobalMetropole__[53] = TextDrawCreate(332.600, 25.499, "/");
    TextDrawLetterSize(LoginGlobalMetropole__[53], 0.939, -0.259);
    TextDrawTextSize(LoginGlobalMetropole__[53], -1.299, 0.000);
    TextDrawAlignment(LoginGlobalMetropole__[53], 1);
    TextDrawColor(LoginGlobalMetropole__[53], -1159848449);
    TextDrawSetShadow(LoginGlobalMetropole__[53], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[53], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[53], 150);
    TextDrawFont(LoginGlobalMetropole__[53], 1);
    TextDrawSetProportional(LoginGlobalMetropole__[53], 1);

    LoginGlobalMetropole__[54] = TextDrawCreate(301.394, 25.798, "LD_BUM:blkdot");
    TextDrawTextSize(LoginGlobalMetropole__[54], 4.899, 2.500);
    TextDrawAlignment(LoginGlobalMetropole__[54], 1);
    TextDrawColor(LoginGlobalMetropole__[54], -1159848449);
    TextDrawSetShadow(LoginGlobalMetropole__[54], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[54], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[54], 255);
    TextDrawFont(LoginGlobalMetropole__[54], 4);
    TextDrawSetProportional(LoginGlobalMetropole__[54], 1);

    LoginGlobalMetropole__[55] = TextDrawCreate(305.500, 16.499, "/");
    TextDrawLetterSize(LoginGlobalMetropole__[55], 0.648, 0.360);
    TextDrawAlignment(LoginGlobalMetropole__[55], 1);
    TextDrawColor(LoginGlobalMetropole__[55], -1159848449);
    TextDrawSetShadow(LoginGlobalMetropole__[55], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[55], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[55], 150);
    TextDrawFont(LoginGlobalMetropole__[55], 1);
    TextDrawSetProportional(LoginGlobalMetropole__[55], 1);

    LoginGlobalMetropole__[56] = TextDrawCreate(284.299, 25.500, "METROPOLE");
    TextDrawLetterSize(LoginGlobalMetropole__[56], 0.337, 1.350);
    TextDrawAlignment(LoginGlobalMetropole__[56], 1);
    TextDrawColor(LoginGlobalMetropole__[56], -1);
    TextDrawSetShadow(LoginGlobalMetropole__[56], 0);
    TextDrawSetOutline(LoginGlobalMetropole__[56], 0);
    TextDrawBackgroundColor(LoginGlobalMetropole__[56], 150);
    TextDrawFont(LoginGlobalMetropole__[56], 1);
    TextDrawSetProportional(LoginGlobalMetropole__[56], 1);    
    return true;
}

stock __CreateLoginPlayerMetropole(playerid) {
    LoginPlayerMetropole__[playerid][0] = CreatePlayerTextDraw(playerid, 272.866, 197.481, "Igor_Aguiar");
    PlayerTextDrawLetterSize(playerid, LoginPlayerMetropole__[playerid][0], 0.179, 0.922);
    PlayerTextDrawAlignment(playerid, LoginPlayerMetropole__[playerid][0], 1);
    PlayerTextDrawColor(playerid, LoginPlayerMetropole__[playerid][0], -1);
    PlayerTextDrawSetShadow(playerid, LoginPlayerMetropole__[playerid][0], 0);
    PlayerTextDrawSetOutline(playerid, LoginPlayerMetropole__[playerid][0], 0);
    PlayerTextDrawBackgroundColor(playerid, LoginPlayerMetropole__[playerid][0], 255);
    PlayerTextDrawFont(playerid, LoginPlayerMetropole__[playerid][0], 1);
    PlayerTextDrawSetProportional(playerid, LoginPlayerMetropole__[playerid][0], 1);

    LoginPlayerMetropole__[playerid][1] = CreatePlayerTextDraw(playerid, 272.866, 230.481, "Digite_sua_senha");
    PlayerTextDrawLetterSize(playerid, LoginPlayerMetropole__[playerid][1], 0.169, 0.922);
    PlayerTextDrawTextSize(playerid, LoginPlayerMetropole__[playerid][1], 330.000, 10.000);
    PlayerTextDrawAlignment(playerid, LoginPlayerMetropole__[playerid][1], 1);
    PlayerTextDrawColor(playerid, LoginPlayerMetropole__[playerid][1], -1);
    PlayerTextDrawSetShadow(playerid, LoginPlayerMetropole__[playerid][1], 0);
    PlayerTextDrawSetOutline(playerid, LoginPlayerMetropole__[playerid][1], 0);
    PlayerTextDrawBackgroundColor(playerid, LoginPlayerMetropole__[playerid][1], 255);
    PlayerTextDrawFont(playerid, LoginPlayerMetropole__[playerid][1], 1);
    PlayerTextDrawSetProportional(playerid, LoginPlayerMetropole__[playerid][1], 1);
    PlayerTextDrawSetSelectable(playerid, LoginPlayerMetropole__[playerid][1], 1);

    LoginPlayerMetropole__[playerid][2] = CreatePlayerTextDraw(playerid, 293.999, 259.688, "REGISTRAR");
    PlayerTextDrawLetterSize(playerid, LoginPlayerMetropole__[playerid][2], 0.222, 1.185);
    PlayerTextDrawTextSize(playerid, LoginPlayerMetropole__[playerid][2], 330.000, 10.000);
    PlayerTextDrawAlignment(playerid, LoginPlayerMetropole__[playerid][2], 1);
    PlayerTextDrawColor(playerid, LoginPlayerMetropole__[playerid][2], -1);
    PlayerTextDrawUseBox(playerid, LoginPlayerMetropole__[playerid][2], 1);
    PlayerTextDrawBoxColor(playerid, LoginPlayerMetropole__[playerid][2], -256);
    PlayerTextDrawSetShadow(playerid, LoginPlayerMetropole__[playerid][2], 0);
    PlayerTextDrawSetOutline(playerid, LoginPlayerMetropole__[playerid][2], 0);
    PlayerTextDrawBackgroundColor(playerid, LoginPlayerMetropole__[playerid][2], 255);
    PlayerTextDrawFont(playerid, LoginPlayerMetropole__[playerid][2], 1);
    PlayerTextDrawSetProportional(playerid, LoginPlayerMetropole__[playerid][2], 1);
    PlayerTextDrawSetSelectable(playerid, LoginPlayerMetropole__[playerid][2], 1);
    return true;
}

stock __CreatePersonagemPMetropole(playerid) {
    CreationPersonagemMetropole__[playerid][0] = CreatePlayerTextDraw(playerid, -172.000, -92.000, "PARTICLE:lamp_shad_64");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][0], 494.000, 541.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][0], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][0], 155);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][0], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][0], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][0], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][0], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][0], 1);

    CreationPersonagemMetropole__[playerid][1] = CreatePlayerTextDraw(playerid, 11.000, 299.000, "LD_SPAC:white");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][1], 109.000, 18.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][1], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][1], -1260050689);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][1], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][1], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][1], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][1], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][1], 1);
    PlayerTextDrawSetSelectable(playerid, CreationPersonagemMetropole__[playerid][1], 1);

    CreationPersonagemMetropole__[playerid][2] = CreatePlayerTextDraw(playerid, 16.000, 294.000, "LD_SPAC:white");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][2], 99.000, 27.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][2], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][2], -1260050689);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][2], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][2], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][2], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][2], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][2], 1);

    CreationPersonagemMetropole__[playerid][3] = CreatePlayerTextDraw(playerid, 8.000, 291.000, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][3], 16.000, 18.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][3], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][3], -1260050689);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][3], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][3], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][3], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][3], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][3], 1);

    CreationPersonagemMetropole__[playerid][4] = CreatePlayerTextDraw(playerid, 8.000, 306.000, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][4], 16.000, 18.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][4], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][4], -1260050689);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][4], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][4], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][4], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][4], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][4], 1);

    CreationPersonagemMetropole__[playerid][5] = CreatePlayerTextDraw(playerid, 108.000, 306.000, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][5], 14.000, 18.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][5], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][5], -1260050689);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][5], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][5], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][5], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][5], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][5], 1);

    CreationPersonagemMetropole__[playerid][6] = CreatePlayerTextDraw(playerid, 108.000, 291.000, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][6], 14.000, 18.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][6], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][6], -1260050689);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][6], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][6], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][6], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][6], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][6], 1);

    CreationPersonagemMetropole__[playerid][7] = CreatePlayerTextDraw(playerid, 11.000, 155.000, "LD_SPAC:white");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][7], 109.000, 18.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][7], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][7], 505290495);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][7], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][7], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][7], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][7], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][7], 1);
    PlayerTextDrawSetSelectable(playerid, CreationPersonagemMetropole__[playerid][7], 1);

    CreationPersonagemMetropole__[playerid][8] = CreatePlayerTextDraw(playerid, 16.000, 150.000, "LD_SPAC:white");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][8], 99.000, 27.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][8], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][8], 505290495);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][8], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][8], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][8], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][8], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][8], 1);

    CreationPersonagemMetropole__[playerid][9] = CreatePlayerTextDraw(playerid, 8.000, 147.000, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][9], 16.000, 18.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][9], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][9], 505290495);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][9], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][9], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][9], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][9], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][9], 1);

    CreationPersonagemMetropole__[playerid][10] = CreatePlayerTextDraw(playerid, 8.000, 162.000, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][10], 17.000, 18.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][10], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][10], 505290495);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][10], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][10], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][10], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][10], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][10], 1);

    CreationPersonagemMetropole__[playerid][11] = CreatePlayerTextDraw(playerid, 108.000, 162.000, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][11], 14.000, 18.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][11], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][11], 505290495);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][11], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][11], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][11], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][11], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][11], 1);

    CreationPersonagemMetropole__[playerid][12] = CreatePlayerTextDraw(playerid, 12.000, 217.000, "LD_SPAC:white");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][12], 106.000, 18.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][12], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][12], 505290495);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][12], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][12], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][12], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][12], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][12], 1);

    CreationPersonagemMetropole__[playerid][13] = CreatePlayerTextDraw(playerid, 108.000, 147.000, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][13], 14.000, 18.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][13], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][13], 505290495);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][13], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][13], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][13], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][13], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][13], 1);

    CreationPersonagemMetropole__[playerid][14] = CreatePlayerTextDraw(playerid, 16.000, 212.000, "LD_SPAC:white");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][14], 99.000, 27.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][14], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][14], 505290495);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][14], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][14], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][14], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][14], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][14], 1);

    CreationPersonagemMetropole__[playerid][15] = CreatePlayerTextDraw(playerid, 8.000, 209.000, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][15], 16.000, 18.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][15], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][15], 505290495);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][15], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][15], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][15], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][15], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][15], 1);

    CreationPersonagemMetropole__[playerid][16] = CreatePlayerTextDraw(playerid, 8.000, 224.000, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][16], 17.000, 18.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][16], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][16], 505290495);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][16], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][16], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][16], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][16], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][16], 1);

    CreationPersonagemMetropole__[playerid][17] = CreatePlayerTextDraw(playerid, 108.000, 224.000, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][17], 14.000, 18.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][17], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][17], 505290495);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][17], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][17], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][17], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][17], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][17], 1);

    CreationPersonagemMetropole__[playerid][18] = CreatePlayerTextDraw(playerid, 108.000, 209.000, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][18], 14.000, 18.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][18], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][18], 505290495);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][18], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][18], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][18], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][18], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][18], 1);

    CreationPersonagemMetropole__[playerid][19] = CreatePlayerTextDraw(playerid, 16.000, 254.000, "LD_SPAC:white");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][19], 99.000, 27.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][19], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][19], 505290495);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][19], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][19], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][19], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][19], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][19], 1);

    CreationPersonagemMetropole__[playerid][20] = CreatePlayerTextDraw(playerid, 12.000, 259.000, "LD_SPAC:white");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][20], 107.000, 18.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][20], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][20], 505290495);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][20], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][20], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][20], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][20], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][20], 1);

    CreationPersonagemMetropole__[playerid][21] = CreatePlayerTextDraw(playerid, 8.000, 251.000, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][21], 16.000, 18.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][21], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][21], 505290495);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][21], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][21], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][21], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][21], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][21], 1);

    CreationPersonagemMetropole__[playerid][22] = CreatePlayerTextDraw(playerid, 8.000, 266.000, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][22], 17.000, 18.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][22], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][22], 505290495);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][22], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][22], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][22], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][22], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][22], 1);

    CreationPersonagemMetropole__[playerid][23] = CreatePlayerTextDraw(playerid, 108.000, 266.000, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][23], 14.000, 18.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][23], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][23], 505290495);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][23], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][23], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][23], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][23], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][23], 1);

    CreationPersonagemMetropole__[playerid][24] = CreatePlayerTextDraw(playerid, 108.000, 251.000, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][24], 14.000, 18.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][24], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][24], 505290495);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][24], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][24], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][24], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][24], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][24], 1);

    CreationPersonagemMetropole__[playerid][25] = CreatePlayerTextDraw(playerid, 36.000, 140.000, "Informacoes_pessoais");
    PlayerTextDrawLetterSize(playerid, CreationPersonagemMetropole__[playerid][25], 0.150, 0.898);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][25], 2);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][25], -2139062017);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][25], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][25], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][25], 150);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][25], 1);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][25], 1);

    CreationPersonagemMetropole__[playerid][26] = CreatePlayerTextDraw(playerid, 32.000, 245.000, "Informe_sua_idade");
    PlayerTextDrawLetterSize(playerid, CreationPersonagemMetropole__[playerid][26], 0.150, 0.898);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][26], 2);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][26], -2139062017);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][26], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][26], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][26], 150);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][26], 1);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][26], 1);

    CreationPersonagemMetropole__[playerid][27] = CreatePlayerTextDraw(playerid, 63.000, 303.000, "CRIAR_PERSONAGEM");
    PlayerTextDrawLetterSize(playerid, CreationPersonagemMetropole__[playerid][27], 0.150, 0.898);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][27], 2);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][27], -1);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][27], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][27], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][27], 150);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][27], 1);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][27], 1);

    CreationPersonagemMetropole__[playerid][28] = CreatePlayerTextDraw(playerid, 21.000, 159.000, "Nome_Sobrenome");
    PlayerTextDrawLetterSize(playerid, CreationPersonagemMetropole__[playerid][28], 0.150, 0.799);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][28], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][28], -1);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][28], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][28], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][28], 150);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][28], 1);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][28], 1);

    CreationPersonagemMetropole__[playerid][29] = CreatePlayerTextDraw(playerid, 62.000, 221.000, "01");
    PlayerTextDrawLetterSize(playerid, CreationPersonagemMetropole__[playerid][29], 0.150, 0.799);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][29], 2);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][29], -1);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][29], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][29], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][29], 150);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][29], 1);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][29], 1);

    CreationPersonagemMetropole__[playerid][30] = CreatePlayerTextDraw(playerid, 62.000, 263.000, "18");
    PlayerTextDrawLetterSize(playerid, CreationPersonagemMetropole__[playerid][30], 0.150, 0.799);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][30], 2);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][30], -1);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][30], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][30], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][30], 150);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][30], 1);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][30], 1);

    CreationPersonagemMetropole__[playerid][31] = CreatePlayerTextDraw(playerid, 5.000, 260.000, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][31], 12.000, 15.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][31], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][31], 1162167807);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][31], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][31], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][31], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][31], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][31], 1);
    PlayerTextDrawSetSelectable(playerid, CreationPersonagemMetropole__[playerid][31], 1);

    CreationPersonagemMetropole__[playerid][32] = CreatePlayerTextDraw(playerid, 113.000, 260.000, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][32], 12.000, 15.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][32], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][32], 1162167807);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][32], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][32], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][32], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][32], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][32], 1);
    PlayerTextDrawSetSelectable(playerid, CreationPersonagemMetropole__[playerid][32], 1);

    CreationPersonagemMetropole__[playerid][33] = CreatePlayerTextDraw(playerid, 9.000, 260.000, "<");
    PlayerTextDrawLetterSize(playerid, CreationPersonagemMetropole__[playerid][33], 0.230, 1.199);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][33], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][33], -1);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][33], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][33], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][33], 150);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][33], 1);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][33], 1);

    CreationPersonagemMetropole__[playerid][34] = CreatePlayerTextDraw(playerid, 118.000, 260.000, ">");
    PlayerTextDrawLetterSize(playerid, CreationPersonagemMetropole__[playerid][34], 0.230, 1.199);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][34], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][34], -1);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][34], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][34], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][34], 150);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][34], 1);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][34], 1);

    CreationPersonagemMetropole__[playerid][35] = CreatePlayerTextDraw(playerid, 5.000, 218.000, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][35], 12.000, 15.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][35], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][35], 1162167807);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][35], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][35], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][35], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][35], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][35], 1);
    PlayerTextDrawSetSelectable(playerid, CreationPersonagemMetropole__[playerid][35], 1);

    CreationPersonagemMetropole__[playerid][36] = CreatePlayerTextDraw(playerid, 113.000, 218.000, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][36], 12.000, 15.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][36], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][36], 1162167807);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][36], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][36], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][36], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][36], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][36], 1);
    PlayerTextDrawSetSelectable(playerid, CreationPersonagemMetropole__[playerid][36], 1);

    CreationPersonagemMetropole__[playerid][37] = CreatePlayerTextDraw(playerid, 9.000, 218.000, "<");
    PlayerTextDrawLetterSize(playerid, CreationPersonagemMetropole__[playerid][37], 0.230, 1.199);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][37], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][37], -1);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][37], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][37], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][37], 150);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][37], 1);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][37], 1);

    CreationPersonagemMetropole__[playerid][38] = CreatePlayerTextDraw(playerid, 118.000, 218.000, ">");
    PlayerTextDrawLetterSize(playerid, CreationPersonagemMetropole__[playerid][38], 0.230, 1.199);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][38], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][38], -1);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][38], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][38], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][38], 150);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][38], 1);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][38], 1);

    CreationPersonagemMetropole__[playerid][39] = CreatePlayerTextDraw(playerid, 52.000, 250.000, "LD_SPAC:white");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][39], 63.000, 1.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][39], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][39], 1768516095);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][39], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][39], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][39], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][39], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][39], 1);

    CreationPersonagemMetropole__[playerid][40] = CreatePlayerTextDraw(playerid, 59.000, 145.000, "LD_SPAC:white");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][40], 56.000, 1.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][40], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][40], 1768516095);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][40], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][40], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][40], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][40], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][40], 1);

    CreationPersonagemMetropole__[playerid][41] = CreatePlayerTextDraw(playerid, 46.000, 127.000, "CRIANDO_PERSONAGEM");
    PlayerTextDrawLetterSize(playerid, CreationPersonagemMetropole__[playerid][41], 0.189, 0.999);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][41], 2);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][41], -1);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][41], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][41], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][41], 150);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][41], 1);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][41], 1);

    CreationPersonagemMetropole__[playerid][42] = CreatePlayerTextDraw(playerid, 16.000, 181.000, "LD_SPAC:white");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][42], 99.000, 27.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][42], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][42], 505290495);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][42], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][42], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][42], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][42], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][42], 1);

    CreationPersonagemMetropole__[playerid][43] = CreatePlayerTextDraw(playerid, 12.000, 186.000, "LD_SPAC:white");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][43], 106.000, 18.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][43], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][43], 505290495);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][43], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][43], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][43], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][43], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][43], 1);

    CreationPersonagemMetropole__[playerid][44] = CreatePlayerTextDraw(playerid, 8.000, 178.000, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][44], 16.000, 18.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][44], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][44], 505290495);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][44], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][44], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][44], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][44], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][44], 1);

    CreationPersonagemMetropole__[playerid][45] = CreatePlayerTextDraw(playerid, 8.000, 193.000, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][45], 17.000, 18.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][45], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][45], 505290495);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][45], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][45], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][45], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][45], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][45], 1);

    CreationPersonagemMetropole__[playerid][46] = CreatePlayerTextDraw(playerid, 108.000, 193.000, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][46], 14.000, 18.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][46], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][46], 505290495);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][46], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][46], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][46], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][46], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][46], 1);

    CreationPersonagemMetropole__[playerid][47] = CreatePlayerTextDraw(playerid, 108.000, 178.000, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][47], 14.000, 18.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][47], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][47], 505290495);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][47], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][47], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][47], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][47], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][47], 1);

    CreationPersonagemMetropole__[playerid][48] = CreatePlayerTextDraw(playerid, 62.000, 190.000, "Masculino");
    PlayerTextDrawLetterSize(playerid, CreationPersonagemMetropole__[playerid][48], 0.150, 0.799);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][48], 2);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][48], -1);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][48], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][48], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][48], 150);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][48], 1);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][48], 1);

    CreationPersonagemMetropole__[playerid][49] = CreatePlayerTextDraw(playerid, 5.000, 187.000, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][49], 12.000, 15.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][49], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][49], 1162167807);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][49], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][49], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][49], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][49], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][49], 1);
    PlayerTextDrawSetSelectable(playerid, CreationPersonagemMetropole__[playerid][49], 1);

    CreationPersonagemMetropole__[playerid][50] = CreatePlayerTextDraw(playerid, 113.000, 187.000, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, CreationPersonagemMetropole__[playerid][50], 12.000, 15.000);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][50], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][50], 1162167807);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][50], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][50], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][50], 255);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][50], 4);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][50], 1);
    PlayerTextDrawSetSelectable(playerid, CreationPersonagemMetropole__[playerid][50], 1);

    CreationPersonagemMetropole__[playerid][51] = CreatePlayerTextDraw(playerid, 9.000, 187.000, "<");
    PlayerTextDrawLetterSize(playerid, CreationPersonagemMetropole__[playerid][51], 0.230, 1.199);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][51], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][51], -1);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][51], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][51], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][51], 150);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][51], 1);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][51], 1);

    CreationPersonagemMetropole__[playerid][52] = CreatePlayerTextDraw(playerid, 118.000, 187.000, ">");
    PlayerTextDrawLetterSize(playerid, CreationPersonagemMetropole__[playerid][52], 0.230, 1.199);
    PlayerTextDrawAlignment(playerid, CreationPersonagemMetropole__[playerid][52], 1);
    PlayerTextDrawColor(playerid, CreationPersonagemMetropole__[playerid][52], -1);
    PlayerTextDrawSetShadow(playerid, CreationPersonagemMetropole__[playerid][52], 0);
    PlayerTextDrawSetOutline(playerid, CreationPersonagemMetropole__[playerid][52], 0);
    PlayerTextDrawBackgroundColor(playerid, CreationPersonagemMetropole__[playerid][52], 150);
    PlayerTextDrawFont(playerid, CreationPersonagemMetropole__[playerid][52], 1);
    PlayerTextDrawSetProportional(playerid, CreationPersonagemMetropole__[playerid][52], 1);
    return true;
}

CMD:saciar(playerid, params[])
{
    PlayerData[playerid][Sono] = 100;
    PlayerData[playerid][Fome] = 100;
    PlayerData[playerid][Sede] = 100;
    PlayerData[playerid][VidaHP] = 100;
    PlayerData[playerid][ColeteHP] = 100;
    SalvarDados(playerid);
}

COMMAND:s60(playerid, params[])
{
    SetPlayerSkin(playerid, 60);
    SetPlayerAttachedObject(playerid, 9, 2992, 2, 0.306000, -0.012000, 0.009000, 0.000000, -95.299942, -1.399999, 1.000000, 1.000000, 1.000000);
    SetPlayerAttachedObject(playerid, 10, 2992, 2, 0.313000, -0.007000, 0.032999, -0.299999, 83.700019, 0.000000, 1.000000, 1.000000, 1.000000);
    return true;
}

public OnPlayerKeyStateChange(playerid, newkeys, oldkeys)
{
    if (newkeys & KEY_YES && IsPlayerInAnyVehicle(playerid))
    {
        PC_EmulateCommand(playerid, "/motor");
    }
    return true;
}

/*function: ClearAnimation(playerid) {
    RemovePlayerAttachedObject(playerid, 5);
    ClearAnimations(playerid, true);
    SegurandoMao[playerid] = 0;
    
    ShowPlayer_Notify(playerid, SOUND_SUCCESS, COLOR_SUCCESS, "SUCCESS", "Voce consumiu um item!", 4);
    return true;
}

COMMAND:loja(playerid, params[])
{
    Dialog_Show(playerid, FunctionLanchonete, DIALOG_STYLE_TABLIST_HEADERS, "{FF8C00}Cardapio",
        "Produto\tValor\n\
        X-Burger\t$10\n\
        X-Bacon\t$40\n\
        X-Tudo\t$50\n\
        Pizza\t$100\n\
        Coca-Cola\t$100\n\
        Fanta Uva\t$50\n\
        Guarana\t$50\n\
        Suco\t$30", "Comprar", "Fechar");
    return true;
}

Dialog:FunctionLanchonete(playerid, response, listitem, inputtext[])
{
    if (!response) return true;

    new itemName[32], itemPrice = 0, objectID;

    switch (listitem)
    {
        case 0: { format(itemName, sizeof(itemName), "X-Burger"); itemPrice = 10; objectID = XBURGER; }
        case 1: { format(itemName, sizeof(itemName), "X-Bacon"); itemPrice = 40; objectID = XBACON; }
        case 2: { format(itemName, sizeof(itemName), "X-Tudo"); itemPrice = 50; objectID = XTUDO; }
        case 3: { format(itemName, sizeof(itemName), "Pizza"); itemPrice = 100; objectID = PIZZA; }
        case 4: { format(itemName, sizeof(itemName), "Coca-Cola"); itemPrice = 100; objectID = COCA; }
        case 5: { format(itemName, sizeof(itemName), "Fanta Uva"); itemPrice = 50; objectID = FANTA; }
        case 6: { format(itemName, sizeof(itemName), "Guarana"); itemPrice = 50; objectID = GUARANA; }
        case 7: { format(itemName, sizeof(itemName), "Suco"); itemPrice = 30; objectID = SUCO; }
        default: { ShowPlayer_Notify(playerid, SOUND_INFORMATION, COLOR_INFORMATION, "INFO", "Opcao invalida", 4); return true; }
    }

    if(GetPlayerMoney(playerid) < itemPrice)
    {
        new mensagem[128];
        format(mensagem, sizeof(mensagem), "Voce nao tem dinheiro suficiente para comprar um(a) %s. Custa $%d.", itemName, itemPrice);
        ShowPlayer_Notify(playerid, SOUND_INFORMATION, COLOR_INFORMATION, "INFO", mensagem, 4);
        return true;
    }

    if (SegurandoMao[playerid] != 0) {
        ShowPlayer_Notify(playerid, SOUND_INFORMATION, COLOR_INFORMATION, "INFO", "Voce ja esta segurando um item. Consuma-o", 4);
        return true;
    }

    GivePlayerMoney(playerid, -itemPrice);
    UsarItem(playerid, objectID);

    new mensagem[128];
    format(mensagem, sizeof(mensagem), "Voce comprou um(a) %s por $%d. Bom apetite!", itemName, itemPrice);
    SendClientMessage(playerid, -1, mensagem);
    return true;
}*/

/*
new gItemPrice[MAX_PLAYERS];
new gItemObjectID[MAX_PLAYERS];
new gItemName[MAX_PLAYERS][32];

function: ShowQuantityDialog(playerid, itemName[], itemPrice, objectID)
{
    new message[128];
    format(message, sizeof(message), "Quanto(a) %s você deseja comprar? (Custo: $%d cada)", itemName, itemPrice);
    
    Dialog_Show(playerid, FunctionLanchoneteQNT, DIALOG_STYLE_INPUT, "Escolha a Quantidade", message, "Confirmar", "Cancelar");
    gItemPrice[playerid] = itemPrice; 
    gItemObjectID[playerid] = objectID; 
    return true;
}

Dialog:FunctionLanchoneteQNT(playerid, response, listitem, inputtext[])
{
    if (response)
    {
        new quantidade = strval(inputtext);
        if (quantidade <= 0)
        {
            ShowPlayer_Notify(playerid, SOUND_INFORMATION, COLOR_INFORMATION, "INFO", "Quantidade inválida.", 4);
            return true;
        }

        new itemPrice = gItemPrice[playerid];
        new totalPrice = itemPrice * quantidade;
        
        if (GetPlayerMoney(playerid) < totalPrice)
        {
            new mensagem[128];
            format(mensagem, sizeof(mensagem), "Você não tem dinheiro suficiente para comprar %d %s. Custo total: $%d.", quantidade, gItemName[playerid], totalPrice);
            ShowPlayer_Notify(playerid, SOUND_INFORMATION, COLOR_INFORMATION, "INFO", mensagem, 4);
            return true;
        }

        if (SegurandoMao[playerid] != 0)
        {
            ShowPlayer_Notify(playerid, SOUND_INFORMATION, COLOR_INFORMATION, "INFO", "Você já está segurando um item. Consuma-o", 4);
            return true;
        }

        GivePlayerMoney(playerid, -totalPrice);

        for (new i = 0; i < quantidade; i++)
        {
            UsarItem(playerid, gItemObjectID[playerid]);
        }

        new mensagem[128];
        format(mensagem, sizeof(mensagem), "Você comprou %d %s por $%d. Bom apetite!", quantidade, gItemName[playerid], totalPrice);
        SendClientMessage(playerid, -1, mensagem);
    }    
    return true;
}

Dialog:FunctionLanchonete(playerid, response, listitem, inputtext[])
{
    if (!response) return true;

    new itemName[32], itemPrice = 0, objectID;

    switch (listitem)
    {
        case 0: { format(itemName, sizeof(itemName), "X-Burger"); itemPrice = 10; objectID = XBURGER; }
        case 1: { format(itemName, sizeof(itemName), "X-Bacon"); itemPrice = 40; objectID = XBACON; }
        case 2: { format(itemName, sizeof(itemName), "X-Tudo"); itemPrice = 50; objectID = XTUDO; }
        case 3: { format(itemName, sizeof(itemName), "Pizza"); itemPrice = 100; objectID = PIZZA; }
        case 4: { format(itemName, sizeof(itemName), "Coca-Cola"); itemPrice = 100; objectID = COCA; }
        case 5: { format(itemName, sizeof(itemName), "Fanta Uva"); itemPrice = 50; objectID = FANTA; }
        case 6: { format(itemName, sizeof(itemName), "Guarana"); itemPrice = 50; objectID = GUARANA; }
        case 7: { format(itemName, sizeof(itemName), "Suco"); itemPrice = 30; objectID = SUCO; }
        default: { ShowPlayer_Notify(playerid, SOUND_INFORMATION, COLOR_INFORMATION, "INFO", "Opção inválida", 4); return true; }
    }
    gItemName[playerid] = itemName;

    ShowQuantityDialog(playerid, itemName, itemPrice, objectID);
    return true;
}
*/

stock GetPlayerProxVehicle(playerid)
{
    new Float:vehiclePos[3];
    for (new vehicleID = 0; vehicleID < MAX_VEHICLES; vehicleID++)
    {
        GetVehiclePos(vehicleID, vehiclePos[0], vehiclePos[1], vehiclePos[2]);
        if (IsPlayerInRangeOfPoint(playerid, 3.0, vehiclePos[0], vehiclePos[1], vehiclePos[2]))
            return vehicleID;
    }
    return 0;
}

COMMAND:fome(playerid, params[])
{
    setPlayerFome(playerid, 40);
    setPlayerSede(playerid, 40);
    setPlayerSono(playerid, 40);
    GivePlayerMoney(playerid, 10000);
    return true;
}

CMD:motor(playerid, params[])
{
    if(IsPlayerInAnyVehicle(playerid))
    {
        if(GetPlayerState(playerid) == PLAYER_STATE_DRIVER)
        {
            new motor, luzes, alarmev, portas, capo, mala, objective;
            new carro = GetPlayerVehicleID(playerid);

            if (IsNoEngineVehicle(carro)) {
                ShowPlayer_Notify(playerid, SOUND_INFORMATION, COLOR_INFORMATION, "INFO", "Este veiculo nao possui motor!", 5);
                return true;
            }

            if(carro != INVALID_VEHICLE_ID)
            {
                if(MotorOn[playerid] == 0) {
                    GetVehicleParamsEx(carro, motor, luzes, alarmev, portas, capo, mala, objective);
                    SetVehicleParamsEx(carro, true, luzes, alarmev, portas, capo, mala, objective);
                    ShowPlayer_Notify(playerid, SOUND_SUCCESS, COLOR_SUCCESS, "SUCCESS", "Voce ligou o motor do seu ve�culo.", 5);
                    MotorOn[playerid] = 1;
                } else {
                    new car = GetPlayerVehicleID(playerid);
                    GetVehicleParamsEx(car, motor, luzes, alarmev, portas, capo, mala, objective);
                    SetVehicleParamsEx(car, false, luzes,alarmev, portas, capo, mala, objective);
                    ShowPlayer_Notify(playerid, SOUND_SUCCESS, COLOR_SUCCESS, "SUCCESS", "Voce desligou o motor do seu ve�culo.", 5);
                    MotorOn[playerid] = 0;
                }
            }
        }    
 	}
    return true;
}

/*clearAuthenticationVariables(playerid)
{
    PlayerData[playerid][Money] = 0;
    PlayerData[playerid][Level] = 0;
    PlayerData[playerid][_Nome] = 0;
    PlayerData[playerid][Skin] = 0;
    PlayerData[playerid][Admin] = 0;
    PlayerData[playerid][Emprego] = 0;
    PlayerData[playerid][Sexo] = 0;
    PlayerData[playerid][Fome] = 0;
    PlayerData[playerid][Sede] = 0;
    PlayerData[playerid][Sono] = 0;

    PlayerData[playerid][Interior] = 0;
    PlayerData[playerid][VirtualW] = 0;
    PlayerData[playerid][VidaHP] = 0;
    PlayerData[playerid][ColeteHP] = 0;
    PlayerData[playerid][PosX] = 0;
    PlayerData[playerid][PosY] = 0;
    PlayerData[playerid][PosZ] = 0;
    PlayerData[playerid][PosR] = 0;

    SegurandoMao[playerid] = 0;
    TentativasSenha[playerid] = 0;
    MotorOn[playerid] = 0;

    VerificarLogin[playerid] = false;
    EstaRegistrado[playerid] = false;

//---------------------------------------------
    KillTimer(TimerFome[playerid]);
	KillTimer(TimerSede[playerid]);
	KillTimer(TimerSono[playerid]);
	KillTimer(TimerVida[playerid]);
	KillTimer(TimerColete[playerid]);
	KillTimer(TimerDormir[playerid]);

    KillTimer(JogadorBike[playerid][BikeTimer]);
    KillTimer(g_TimerFishing[playerid]);
    KillTimer(playerLoadingTimer[playerid]);
    KillTimer(notifyTimer[playerid][_notify]);
    KillTimer(TimerBarrinha[playerid]);
    KillTimer(PlayerVelocimetroTimer[playerid]);

//---------------------------------------------
	RemovePlayerAttachedObject(playerid, 0);
	RemovePlayerAttachedObject(playerid, 1);
	RemovePlayerAttachedObject(playerid, 2);
	RemovePlayerAttachedObject(playerid, 3);
	RemovePlayerAttachedObject(playerid, 4);
	RemovePlayerAttachedObject(playerid, 5);
	RemovePlayerAttachedObject(playerid, 6);
	RemovePlayerAttachedObject(playerid, 7);
    RemovePlayerAttachedObject(playerid, 8);
    RemovePlayerAttachedObject(playerid, 9);
	RemovePlayerAttachedObject(playerid, 10);
    return 1;
}*/

COMMAND:vida(playerid, params[])
{
    OnPlayerGiveDamage(playerid, playerid, 200.0, 31, 9);
    return true;
}

new PlayerText:TDEditor_PTD[MAX_PLAYERS][38];


stock LoadTextDraw(playerid) {
    TDEditor_PTD[playerid][0] = CreatePlayerTextDraw(playerid, 615.666687, 11.214812, "I");
    PlayerTextDrawLetterSize(playerid, TDEditor_PTD[playerid][0], 0.207663, 1.670518);
    PlayerTextDrawTextSize(playerid, TDEditor_PTD[playerid][0], -22.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][0], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][0], -1375784961);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][0], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][0], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][0], 1);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][0], 1);

    TDEditor_PTD[playerid][1] = CreatePlayerTextDraw(playerid, 627.463806, 11.414813, "I");
    PlayerTextDrawLetterSize(playerid, TDEditor_PTD[playerid][1], 0.177663, 1.670518);
    PlayerTextDrawTextSize(playerid, TDEditor_PTD[playerid][1], -22.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][1], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][1], -1375784961);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][1], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][1], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][1], 1);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][1], 1);

    TDEditor_PTD[playerid][2] = CreatePlayerTextDraw(playerid, 615.000061, 11.911122, "/");
    PlayerTextDrawLetterSize(playerid, TDEditor_PTD[playerid][2], 0.364665, 0.343111);
    PlayerTextDrawTextSize(playerid, TDEditor_PTD[playerid][2], -22.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][2], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][2], -1375784961);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][2], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][2], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][2], 1);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][2], 1);

    TDEditor_PTD[playerid][3] = CreatePlayerTextDraw(playerid, 617.999328, 9.311112, "/");
    PlayerTextDrawLetterSize(playerid, TDEditor_PTD[playerid][3], 0.364665, 0.343111);
    PlayerTextDrawTextSize(playerid, TDEditor_PTD[playerid][3], -22.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][3], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][3], -1375784961);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][3], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][3], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][3], 1);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][3], 1);

    TDEditor_PTD[playerid][4] = CreatePlayerTextDraw(playerid, 623.797912, 23.811166, "/");
    PlayerTextDrawLetterSize(playerid, TDEditor_PTD[playerid][4], 0.364665, 0.343111);
    PlayerTextDrawTextSize(playerid, TDEditor_PTD[playerid][4], -22.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][4], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][4], -1375784961);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][4], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][4], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][4], 1);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][4], 1);

    TDEditor_PTD[playerid][5] = CreatePlayerTextDraw(playerid, 621.398498, 25.911174, "/");
    PlayerTextDrawLetterSize(playerid, TDEditor_PTD[playerid][5], 0.364665, 0.343111);
    PlayerTextDrawTextSize(playerid, TDEditor_PTD[playerid][5], -22.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][5], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][5], -1375784961);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][5], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][5], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][5], 1);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][5], 1);

    TDEditor_PTD[playerid][6] = CreatePlayerTextDraw(playerid, 617.199951, 13.862931, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, TDEditor_PTD[playerid][6], 10.000000, 11.750040);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][6], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][6], -171);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][6], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][6], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][6], 4);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][6], 0);

    TDEditor_PTD[playerid][7] = CreatePlayerTextDraw(playerid, 618.199707, 15.162936, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, TDEditor_PTD[playerid][7], 8.000000, 9.000000);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][7], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][7], -171);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][7], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][7], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][7], 4);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][7], 0);

    TDEditor_PTD[playerid][8] = CreatePlayerTextDraw(playerid, 621.066467, 16.777730, "I");
    PlayerTextDrawLetterSize(playerid, TDEditor_PTD[playerid][8], 0.149333, 0.484369);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][8], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][8], -1);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][8], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][8], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][8], 1);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][8], 1);

    TDEditor_PTD[playerid][9] = CreatePlayerTextDraw(playerid, 621.566345, 17.577732, "-");
    PlayerTextDrawLetterSize(playerid, TDEditor_PTD[playerid][9], 0.175330, 0.434370);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][9], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][9], -1);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][9], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][9], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][9], 1);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][9], 1);

    TDEditor_PTD[playerid][10] = CreatePlayerTextDraw(playerid, 613.799499, 11.503689, "Quarta-Feira");
    PlayerTextDrawLetterSize(playerid, TDEditor_PTD[playerid][10], 0.144333, 0.770370);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][10], 3);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][10], 1768515993);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][10], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][10], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][10], 1);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][10], 1);

    TDEditor_PTD[playerid][11] = CreatePlayerTextDraw(playerid, 605.567382, 18.970354, "14h33");
    PlayerTextDrawLetterSize(playerid, TDEditor_PTD[playerid][11], 0.155663, 0.840888);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][11], 2);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][11], -1);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][11], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][11], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][11], 1);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][11], 1);

    TDEditor_PTD[playerid][12] = CreatePlayerTextDraw(playerid, 607.268737, 29.714881, "I");
    PlayerTextDrawLetterSize(playerid, TDEditor_PTD[playerid][12], 0.207663, 1.670518);
    PlayerTextDrawTextSize(playerid, TDEditor_PTD[playerid][12], -22.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][12], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][12], -1375784961);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][12], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][12], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][12], 1);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][12], 1);

    TDEditor_PTD[playerid][13] = CreatePlayerTextDraw(playerid, 617.966125, 29.714881, "I");
    PlayerTextDrawLetterSize(playerid, TDEditor_PTD[playerid][13], 0.207663, 1.670518);
    PlayerTextDrawTextSize(playerid, TDEditor_PTD[playerid][13], -22.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][13], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][13], -1375784961);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][13], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][13], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][13], 1);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][13], 1);

    TDEditor_PTD[playerid][14] = CreatePlayerTextDraw(playerid, 606.700195, 30.162960, "/");
    PlayerTextDrawLetterSize(playerid, TDEditor_PTD[playerid][14], 0.364665, 0.343111);
    PlayerTextDrawTextSize(playerid, TDEditor_PTD[playerid][14], -22.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][14], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][14], -1375784961);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][14], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][14], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][14], 1);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][14], 1);

    TDEditor_PTD[playerid][15] = CreatePlayerTextDraw(playerid, 609.199584, 27.862951, "/");
    PlayerTextDrawLetterSize(playerid, TDEditor_PTD[playerid][15], 0.364665, 0.343111);
    PlayerTextDrawTextSize(playerid, TDEditor_PTD[playerid][15], -22.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][15], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][15], -1375784961);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][15], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][15], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][15], 1);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][15], 1);

    TDEditor_PTD[playerid][16] = CreatePlayerTextDraw(playerid, 614.098388, 42.077632, "/");
    PlayerTextDrawLetterSize(playerid, TDEditor_PTD[playerid][16], 0.364665, 0.343111);
    PlayerTextDrawTextSize(playerid, TDEditor_PTD[playerid][16], -22.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][16], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][16], -1375784961);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][16], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][16], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][16], 1);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][16], 1);

    TDEditor_PTD[playerid][17] = CreatePlayerTextDraw(playerid, 612.298828, 43.577610, "/");
    PlayerTextDrawLetterSize(playerid, TDEditor_PTD[playerid][17], 0.364665, 0.343111);
    PlayerTextDrawTextSize(playerid, TDEditor_PTD[playerid][17], -22.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][17], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][17], -1375784961);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][17], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][17], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][17], 1);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][17], 1);

    TDEditor_PTD[playerid][18] = CreatePlayerTextDraw(playerid, 608.300048, 31.685146, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, TDEditor_PTD[playerid][18], 10.000000, 11.750040);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][18], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][18], -171);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][18], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][18], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][18], 4);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][18], 0);

    TDEditor_PTD[playerid][19] = CreatePlayerTextDraw(playerid, 612.500122, 38.488849, "I");
    PlayerTextDrawLetterSize(playerid, TDEditor_PTD[playerid][19], 0.241999, 0.275110);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][19], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][19], -1);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][19], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][19], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][19], 1);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][19], 1);

    TDEditor_PTD[playerid][20] = CreatePlayerTextDraw(playerid, 610.933959, 33.840744, "U");
    PlayerTextDrawLetterSize(playerid, TDEditor_PTD[playerid][20], 0.182330, 0.727258);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][20], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][20], -1);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][20], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][20], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][20], 2);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][20], 1);

    TDEditor_PTD[playerid][21] = CreatePlayerTextDraw(playerid, 611.799804, 32.629615, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, TDEditor_PTD[playerid][21], 3.000000, 7.000000);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][21], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][21], -1);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][21], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][21], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][21], 4);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][21], 0);

    TDEditor_PTD[playerid][22] = CreatePlayerTextDraw(playerid, 605.799499, 30.799976, "Tom_de_Voz");
    PlayerTextDrawLetterSize(playerid, TDEditor_PTD[playerid][22], 0.144333, 0.770370);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][22], 3);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][22], 1768515993);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][22], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][22], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][22], 1);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][22], 1);

    TDEditor_PTD[playerid][23] = CreatePlayerTextDraw(playerid, 606.067321, 37.451831, "Normal");
    PlayerTextDrawLetterSize(playerid, TDEditor_PTD[playerid][23], 0.140663, 0.762072);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][23], 3);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][23], -1);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][23], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][23], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][23], 1);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][23], 1);

    TDEditor_PTD[playerid][24] = CreatePlayerTextDraw(playerid, 615.666687, 47.914646, "I");
    PlayerTextDrawLetterSize(playerid, TDEditor_PTD[playerid][24], 0.207663, 1.670518);
    PlayerTextDrawTextSize(playerid, TDEditor_PTD[playerid][24], -22.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][24], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][24], -1375784961);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][24], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][24], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][24], 1);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][24], 1);

    TDEditor_PTD[playerid][25] = CreatePlayerTextDraw(playerid, 627.463806, 47.814647, "I");
    PlayerTextDrawLetterSize(playerid, TDEditor_PTD[playerid][25], 0.177663, 1.670518);
    PlayerTextDrawTextSize(playerid, TDEditor_PTD[playerid][25], -22.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][25], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][25], -1375784961);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][25], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][25], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][25], 1);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][25], 1);

    TDEditor_PTD[playerid][26] = CreatePlayerTextDraw(playerid, 615.000061, 48.410945, "/");
    PlayerTextDrawLetterSize(playerid, TDEditor_PTD[playerid][26], 0.364665, 0.343111);
    PlayerTextDrawTextSize(playerid, TDEditor_PTD[playerid][26], -22.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][26], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][26], -1375784961);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][26], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][26], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][26], 1);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][26], 1);

    TDEditor_PTD[playerid][27] = CreatePlayerTextDraw(playerid, 617.899353, 45.810985, "/");
    PlayerTextDrawLetterSize(playerid, TDEditor_PTD[playerid][27], 0.364665, 0.343111);
    PlayerTextDrawTextSize(playerid, TDEditor_PTD[playerid][27], -22.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][27], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][27], -1375784961);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][27], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][27], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][27], 1);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][27], 1);

    TDEditor_PTD[playerid][28] = CreatePlayerTextDraw(playerid, 623.797912, 59.510776, "/");
    PlayerTextDrawLetterSize(playerid, TDEditor_PTD[playerid][28], 0.364665, 0.343111);
    PlayerTextDrawTextSize(playerid, TDEditor_PTD[playerid][28], -22.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][28], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][28], -1375784961);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][28], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][28], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][28], 1);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][28], 1);

    TDEditor_PTD[playerid][29] = CreatePlayerTextDraw(playerid, 620.698669, 62.110736, "/");
    PlayerTextDrawLetterSize(playerid, TDEditor_PTD[playerid][29], 0.364665, 0.343111);
    PlayerTextDrawTextSize(playerid, TDEditor_PTD[playerid][29], -22.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][29], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][29], -1375784961);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][29], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][29], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][29], 1);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][29], 1);

    TDEditor_PTD[playerid][30] = CreatePlayerTextDraw(playerid, 620.299804, 54.914829, "LD_SPAC:white");
    PlayerTextDrawTextSize(playerid, TDEditor_PTD[playerid][30], 4.000000, 5.000000);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][30], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][30], -1);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][30], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][30], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][30], 4);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][30], 0);

    TDEditor_PTD[playerid][31] = CreatePlayerTextDraw(playerid, 619.132873, 50.711143, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, TDEditor_PTD[playerid][31], 6.119976, 7.000000);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][31], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][31], -1);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][31], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][31], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][31], 4);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][31], 0);

    TDEditor_PTD[playerid][32] = CreatePlayerTextDraw(playerid, 620.432556, 51.911125, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, TDEditor_PTD[playerid][32], 3.399930, 4.359939);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][32], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][32], 255);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][32], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][32], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][32], 4);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][32], 0);

    TDEditor_PTD[playerid][33] = CreatePlayerTextDraw(playerid, 619.932678, 55.711067, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, TDEditor_PTD[playerid][33], 2.429933, 3.149930);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][33], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][33], 255);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][33], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][33], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][33], 4);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][33], 0);

    TDEditor_PTD[playerid][34] = CreatePlayerTextDraw(playerid, 622.332092, 56.911048, "LD_BEAT:chit");
    PlayerTextDrawTextSize(playerid, TDEditor_PTD[playerid][34], 2.429933, 3.149930);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][34], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][34], 255);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][34], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][34], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][34], 4);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][34], 0);

    TDEditor_PTD[playerid][35] = CreatePlayerTextDraw(playerid, 620.099914, 50.566677, "LD_SPAC:white");
    PlayerTextDrawTextSize(playerid, TDEditor_PTD[playerid][35], 1.000000, 3.000000);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][35], 1);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][35], -1);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][35], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][35], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][35], 4);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][35], 0);

    TDEditor_PTD[playerid][36] = CreatePlayerTextDraw(playerid, 614.232604, 49.999870, "Radio");
    PlayerTextDrawLetterSize(playerid, TDEditor_PTD[playerid][36], 0.144333, 0.770370);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][36], 3);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][36], 1768515993);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][36], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][36], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][36], 1);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][36], 1);

    TDEditor_PTD[playerid][37] = CreatePlayerTextDraw(playerid, 614.300354, 57.429519, "190Mhz");
    PlayerTextDrawLetterSize(playerid, TDEditor_PTD[playerid][37], 0.112332, 0.654222);
    PlayerTextDrawAlignment(playerid, TDEditor_PTD[playerid][37], 3);
    PlayerTextDrawColor(playerid, TDEditor_PTD[playerid][37], -1);
    PlayerTextDrawSetShadow(playerid, TDEditor_PTD[playerid][37], 0);
    PlayerTextDrawBackgroundColor(playerid, TDEditor_PTD[playerid][37], 255);
    PlayerTextDrawFont(playerid, TDEditor_PTD[playerid][37], 1);
    PlayerTextDrawSetProportional(playerid, TDEditor_PTD[playerid][37], 1);

    for(new i = 0; i < sizeof(TDEditor_PTD[]); i++)
        PlayerTextDrawShow(playerid, TDEditor_PTD[playerid][i]);
    return true;
}

COMMAND:text(playerid, params[])
{
    LoadTextDraw(playerid);
    return true;
}

COMMAND:radio(playerid, params[])
{
    new radio;
    if(sscanf(params, "d", radio))
        return true;

    new string[64];
    format(string, sizeof(string), "%dMhz", radio);
    PlayerTextDrawSetString(playerid, TDEditor_PTD[playerid][37], string);
    return true;
}